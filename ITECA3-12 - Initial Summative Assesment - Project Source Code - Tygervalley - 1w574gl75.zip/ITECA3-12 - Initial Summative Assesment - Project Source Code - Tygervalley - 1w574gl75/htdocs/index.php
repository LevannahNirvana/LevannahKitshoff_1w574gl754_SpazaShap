<!-- Levannah Kitshoff - May 2025 - REDIRECT TO welcome_landing.php -->
<?php
/* header("Location: /SpazaShapDraft2/welcome_landing.php");  *///Redirects to the welcome page
header("Location: /SpazaShapDraft2/login.html"); 
exit();
?>

