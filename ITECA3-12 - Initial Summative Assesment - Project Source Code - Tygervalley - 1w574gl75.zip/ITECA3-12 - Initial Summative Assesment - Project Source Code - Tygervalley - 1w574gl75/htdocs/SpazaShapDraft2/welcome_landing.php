<!-- Levannah Kitshoff 1w574gl75  - May 2025 
     Final - Neater version of - welcome_landing.php page
-->
<?php
session_start(); //Start session

//----------------------DATABASE CONNECTION----------------------
//------------- DATABASE CONNECT (INSERT PRODUCT)   *PROCEDURAL
//#1 DB Connection Variables & #2 DB CONNECT & #3 CHECK DB CONNECT 
require_once 'include/dbconnect.php';  
//works - inside same directory is include file - within it is dbconnect

//-------- all in stock products (sql query and result) ----------
$sql_all_products = "SELECT * FROM products WHERE productStockQuantity>0";
$all_products_result = mysqli_query($conn, $sql_all_products);

//---------------------------------------------------------------------------
$sql_check_admin_email = "SELECT * FROM admins WHERE adminEmail ='$email'";
$admin_check = mysqli_query($conn, $sql_check_admin_email);
?>

<!-- HTML DOCUMENT for Welcome Landing Page -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome User</title>

    <link rel="stylesheet" href="styleV2.css">
    <!-- <link rel="stylesheet" href="navigation_style.css"> --> 

    <style>

        main {padding-top: 100px; } 

        @media screen and (max-width: 768px) {
            main {padding-top: 140px; } 
        }

    </style>
</head>

<body>

    <header>
        <?php /* include 'include/navigation.php'; */ ?>
        <nav class="navigationBar">

            <div class="leftNavigation">
                <!-- Clickable Logo & Text to redirect to Home / Welcome Landing Page -->
                <a href="welcome_landing.php">
                    <!-- Logo -->
                    <div class="logoSpazaShap">
                        <img src="images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                        <!-- keep image source as is !! -->
                        <p>Spaza Shap: Shopping Spaza Style</p>
                    </div>
                </a>

                <!-- Left Navigation Links (Home, Products, About) -->
                <ul class="navigationBarList leftNavLinks">
                    <li><a href="welcome_landing.php">Home</a></li>
                    <li><a href="view_all_products.php">Products</a></li> 
                    <!--Products - buy product (buyers)-->
                    <li><a href="about.php">About</a></li>
                </ul>
            </div>

            <!-- Search Bar -->
            <div class="centerNavigation">
                <!-- <form class="searchForm" action="search_product.php" method="GET"> -->
                <form class="navSearchForm" action="view_all_products.php" method="GET">
                    <input type="search" id="search" name="search" placeholder="Search for product...">
                    <button class="navSearchButton" name="navSearchButton">Search</button>
                </form>
            </div>

            <!-- Right Navigation Links (Register Login) (Cart, Profile)   **removed profile for base model-->
            <div class="rightNavigation navigationBarList">
                <ul class="navigationBarList rightNavLinks">
                
                        <!-- Guest User  -->
                        <?php if (!isset($_SESSION['userLoggedIn'])): {  ?>
                            <li><a href="nonUser_index.php" class="navButton">Register</a></li>
                            <li><a href="login.html" class="navButton">Login</a></li>
                        <!-- admin vs buyer vs seller -->
                        
                        <!-- ADMIN -->
                        <?php  }elseif ($_SESSION["userRole"] == "Admin"): { ?>
                            <li><a href="admin/admin_panel.php" class="navButton">Admin Panel </a></li>
                            <li><a href="logout.php" class="navButton">Logout</a></li>
            
                        <!-- SELLER -->
                        <?php  }elseif ($_SESSION["userRole"] == "Seller"): { ?>
                            <li><a href="seller/seller_panel.php" class="navButton">Seller Panel </a></li>
                            <li><a href="logout.php" class="navButton">Logout</a></li>

                        <!-- BUYER (ELSE) -->
                        <?php  }elseif ($_SESSION["userRole"] == "Buyer"): { ?>
                            <li><a href="buyer_cart.php" class="navButton">Cart</a></li>
                            <li><a href="logout.php" class="navButton">Logout</a></li>

                    <?php } endif; ?>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <br><br>
        <h2>Welcome to Spaza Shap: </h2>

        <div class="productCardContainer">
            <?php
            while ($productRow = mysqli_fetch_assoc($all_products_result)) {
            ?>
            <!-- =================  PRODUCT CARD ===================   -->
            <div class="productCard">
                <h4><?php echo $productRow['productName'] ?></h4>
                <img class="productImageSource" alt="product image"
                    src="product_images/<?php echo htmlspecialchars($productRow['productImageSource']) ?>">
                
                <p class="productPrice">R<?php echo $productRow['productPrice'] ?></p>
                <p class="productDescription"><?php echo $productRow['productDescription'] ?></p>

                <!-- a instead of button to redirect to login for nonuser, stay on same page as seller/admin, but continue as buyer -->
                <?php
                    /* User not logged in */
                    if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true){
                ?>
                        <p><a href="login.html" class="addProductToCartBtn">Add to Cart</a></p>

                <?php
                    /* user = buyer --- can proceed to cart to order + pay */
                    }else if ($_SESSION["userRole"] == "Buyer"){

                        //added for buyer buying *new
                        $email = $_SESSION["email"]; 
                ?>
                    <!-- <p><a href="" class="addProductToCartBtn">Add to Cart</a></p> -->
                        <p><a class="addProductToCartBtn"
                        href="add_to_cart.php?productID=<?php echo $productRow['productID']?>&buyerEmail=<?php echo $email ?>">Add to Cart</a></p> <!-- fixed %20 spaces in url -->
                        
                <?php
                    }else  { 
                        /*if ($_SESSION["userRole"] == "Seller")*/
                        /*if ($_SESSION["userRole"] == "Admin")*/
                ?>
                    <p><a href="" class="addProductToCartBtn">Add to Cart</a></p> 
                    <!-- empty href - stay on same page -->
                <?php
                    }
                ?>

            </div>
            <?php } ?>
        </div>
    </main>

    <!-- FOOTER -->
    <?php include 'include/footer.php'; ?>

    <script></script>
</body>
</html>