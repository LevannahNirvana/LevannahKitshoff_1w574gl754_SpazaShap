<?php
//Levannah kitshoff - June 2025
// admin_view_orders.php
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  ADMIN  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html");  //or ../welcome_landing.php")
    exit();
}

//if not a ADMIN **CHECK ROLE   (should only allow admin access here)
if ($_SESSION["userRole"] != "Admin") {
    header("Location: ../welcome_landing.php"); //or admin/admin_panel if role is admin
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Admins"; //maybe give a message ???
}

//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once '../include/dbconnect.php'; 
?>

<?php

//---DELETE FUNCTIONALITY ADDED--- 
if (isset($_GET['orderID'])) {
    //if -->  delete button clicked -- gets +sets the orderID
    $orderID = $_GET['orderID'];
    $delete_order_sql = "DELETE FROM orders where orderID='$orderID' ";
    $order_data = mysqli_query($conn, $delete_order_sql);
    if ($order_data) {
        header("Location: admin_view_orders.php"); //if successful - send user to same place
    }
}
//-------------fin delete-----------------

//---UPDATE FUNCTIONALITY --- on admin_update_orders.php page


//VIEW ALL ORDERS -- for all buyers  **where Placed or Paid  (not cart)
$sql_orders = "SELECT * FROM orders WHERE orderStatus = 'Placed' OR orderStatus = 'Paid'";
$all_buyer_orders_result  = mysqli_query($conn, $sql_orders);

//error handling -- if unsuccessful query for all orders
if (!$all_buyer_orders_result ) {
    die("Orders Query Error: ".mysqli_error($conn));
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin: All Orders</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css">
    <link rel="stylesheet" href="admin_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->

    <style>
        /* =======================ADMIN VIEW ORDERS PAGE================*/
        /* all above layout repeats throughout the panel pages */

        /* table class="admin_table_orders" */
        .admin_table_orders {
            border: 3px solid black;
            margin-top: 35px;
        }

        th {
            background: #2f84d9;
            font-weight: bold;
            text-align: center;
            padding: 9px;
        }

        td {
            text-align: center;
            padding: 10px 5px;
            margin: 5px 5px;
        }

        /* ===================ADMIN UPDATE/DELETE ORDERS PAGE==============*/
        /* =======DELETE ORDERS ======== */
        .panel_delete_btn {
            border-radius: 15px;
            background: red;
            padding: 8px;
        }
        .panel_delete_btn:hover {
            background-color: darkred;
        }

        /* =======UPDATE ORDERS ======== */
        .panel_update_btn {
            border-radius: 15px;
            background: orange;
            padding: 8px;
        }
        .panel_update_btn:hover {
            background-color: darkorange;
        }

    </style>

</head>

<body>

    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="adminPanelContainer">

            <!-- Admin panel sidebar (left shows functionality within ul>li) -->
            <div class="adminPanelSidebar">
                <!-- Logo -->
                <div class="logoSpazaShapPanel">
                    <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo"        
                    style="align-content:center;">
                </div>
                <h2>SpazaShap Admin</h2>
                <!-- <hr> -->
                <ul>
                    <li>
                        <a href="admin_panel.php">Admin Panel</a>
                    </li>
                    <li>
                        <a href="admin_view_buyers.php">Buyers</a>
                    </li>
                    <li>
                        <a href="admin_view_sellers.php">Sellers</a>
                    </li>
                    <li>
                        <a href="admin_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="admin_view_orders.php">Orders</a>
                    </li>
                    <li>
                        <a href="admin_view_orders.php">Orders</a>
                    </li>
                </ul>
            </div>

            <div class="adminContentRight">
                <h1> Admin Panel: All Orders</h1>

                <table class="admin_table_orders">
                        <!-- Table Row -- for headers -->
                        <tr>
                            <th>OrderID</th>
                            <th>Order Date</th>
                            <th>Order Total</th>
                            <th>Order Status </th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>
            <?php
            if ($all_buyer_orders_result && mysqli_num_rows($all_buyer_orders_result) > 0) {
                while ($orderRow = mysqli_fetch_assoc($all_buyer_orders_result)) {
            ?>
                    <!-- Table row for Data (4 headers thus 4 data) -->
                <tr>
                    <!--orderID-->
                    <td><?php echo $orderRow['orderID'] ?></td>
                    <!--orderDate-->
                    <td><?php echo $orderRow['orderDate'] ?></td>
                    <!--orderTotal-->
                    <td><?php echo $orderRow['orderTotal'] ?></td>
                    <!--orderStatus-->
                    <td><?php echo $orderRow['orderStatus'] ?></td>

                    <!-- Delete -->
                    <td>
                        <a href="admin_view_orders.php?orderID=<?php echo $orderRow['orderID']; ?>" 
                        class="panel_delete_btn" 
                        onclick="return confirm('Are you sure you want to DELETE this ORDER?');">Delete</a>
                    </td>
                    <!-- Update -->
                    <td>
                        <a href="admin_update_orders.php?orderID=<?php echo $orderRow['orderID']; ?>" 
                        class="panel_update_btn">Update</a>
                    </td>
                </tr>
                   
            <?php }
            } else {
                echo "<p>No Orders found.</p>";
            }
            ?>
        </table>
        <br><br>
        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>

</body>
</html>