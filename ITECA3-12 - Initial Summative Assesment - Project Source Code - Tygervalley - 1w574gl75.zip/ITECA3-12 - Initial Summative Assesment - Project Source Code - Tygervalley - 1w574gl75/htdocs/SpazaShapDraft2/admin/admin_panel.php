<?php
//Levannah Kitshoff - May 2025 
//admin_panel.php
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html"); //or login.html
    exit();
}

//if not a ADMIN **CHECK ROLE   (should only allow admin access here)
if ($_SESSION["userRole"] != "Admin") {
    header("Location: ../welcome_landing.php"); //or admin/admin_panel.php
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Admins";
}
?>

<?php
//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once '../include/dbconnect.php';

// ============== SQL FOR COUNTS ===============
//BUYERS -- "SELECT COUNT() FROM buyers;";  or "SELECT * FROM buyers" 
$sql_count_buyers = "SELECT * FROM buyers;";
$count_buyer_result = mysqli_query($conn, $sql_count_buyers); //query connection to db 
$total_buyers = mysqli_num_rows($count_buyer_result); //counts rows 

//SELLERS -- "SELECT COUNT() FROM sellers;";  or "SELECT * FROM sellers" 
$sql_count_sellers = "SELECT * FROM sellers;";
$count_seller_result = mysqli_query($conn, $sql_count_sellers);
$total_sellers = mysqli_num_rows($count_seller_result);

//PRODUCTS -- "SELECT COUNT() FROM products;";  or "SELECT * FROM products" 
$sql_count_products = "SELECT * FROM products";
$count_product_result = mysqli_query($conn, $sql_count_products);
$total_products = mysqli_num_rows($count_product_result);

/* ------------------------------------------------------------------------  */
//ORDERS -- "SELECT COUNT() FROM orders;";  or "SELECT * FROM orders" 
$sql_count_orders= "SELECT * FROM orders WHERE orderStatus = 'Placed' OR orderStatus = 'Paid'";
$count_order_result = mysqli_query($conn, $sql_count_orders);  
$total_orders = mysqli_num_rows($count_order_result); 

/* STILL DO!!!!!  */
//ORDERS -- "SELECT COUNT() FROM deliveries;";  or "SELECT * FROM deliveries" 
/* $sql_count_deliveries= "SELECT * FROM orders WHERE orderStatus = 'Delivered'" ;
$sql_count_deliveries= "SELECT * FROM order_tracking WHERE trackingStatus = 'Delivered'" ;
$count_delivery_result = mysqli_query($conn, $sql_count_deliveries);  
$total_deliveries = mysqli_num_rows($count_delivery_result);  */
/* ------------------------------------------------------------------------ */

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css">
    <link rel="stylesheet" href="admin_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->

    <style>
        /* --------------------- */
        .adminContentRight {padding: 0 5px;}
        /* --------------------- */
        .adminPanelDashboardCards {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;/* added to wrap around */
        }

        .adminPanelBuyersCard,
        .adminPanelSellersCard,
        .adminPanelProductsCard,
        .adminPanelOrdersCard,
        .adminPanelDeliveriesCard {
            width: 200px;
            background: black;
            color: white;
            margin: 10px;
            padding: 2px 10px;
        }
        .adminPanelBuyersCard p {
            color: #459349;
            padding: 10px;
            font-weight: bold;
        }
        .adminPanelSellersCard p {
            color: #2f84d9;
            padding: 10px;
            font-weight: bold;
        }
        .adminPanelProductsCard p {
            color: blueviolet;
            padding: 10px;
            font-weight: bold;
        }
        .adminPanelOrdersCard p {
            color: goldenrod;
            padding: 10px;
            font-weight: bold;
        }
        .adminPanelDeliveriesCard p {
            color: pink;
            padding: 10px;
            font-weight: bold;
        }

    </style>
</head>

<body>
    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo">
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="adminPanelContainer">
            <!-- Admin panel sidebar (left shows functionality within ul>li) -->
            <div class="adminPanelSidebar">
                <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
                <li><a href="../welcome_landing.php">
                        <!-- Logo -->
                        <div class="logoSpazaShapPanel">
                            <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                            style="align-content:center;">
                        </div>
                    </a>
                </li>

                <h2>SpazaShap Admin</h2>
                <!-- <hr> -->
                <ul>
                    <li>
                        <a href="admin_panel.php">Admin Panel</a>
                    </li>
                    <li>
                        <a href="admin_view_buyers.php">Buyers</a>
                    </li>
                    <li>
                        <a href="admin_view_sellers.php">Sellers</a>
                    </li>
                    <li>
                        <a href="admin_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="admin_view_orders.php">Orders</a>
                    </li>
                </ul>
            </div>

            <div class="adminContentRight">

                <div class="adminPanelDashboardCards">
                    <div class="adminPanelBuyersCard">
                        <!-- #NR USERS (BUYERS)  :) -->
                        <h3>Total Buyers:</h3>
                        <hr>
                        <p> <?php echo $total_buyers ?> </p>

                    </div>

                    <div class="adminPanelSellersCard">
                        <!-- #NR USERS (SELLERS) -->
                        <h3>Total Sellers:</h3>
                        <hr>
                        <p>
                            <?php echo $total_sellers  ?>
                        </p>

                    </div>

                    <div class="adminPanelProductsCard">
                        <!-- #NR PRODUCTS -->
                        <h3>Total Products:</h3>
                        <hr>
                        <p>
                            <?php echo $total_products ?>
                        </p>

                    </div>

                    <div class="adminPanelOrdersCard">
                        <!-- #NR ORDERS  0 at first-->
                        <h3>Total Orders:</h3>
                        <hr>
                        <p>
                            <?php echo $total_orders ?>
                        </p>
                    </div>

                    <!-- #NR DELIVERIES -->
                    <!-- <div class="adminPanelDeliveriesCard">
                        <h3>Total Deliveries:</h3>
                        <hr>
                        <p> 0
                            <?php /* echo $total_deliveries  */ ?>
                        </p>
                    </div> -->
                </div>
            </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>