<?php
/* Levannah Kitshoff - 4 June -- 
-- admin_view_sellers.php */

//--------------- SESSIONS --------------
session_start();
//----CHECK userLoggedIn  & CHECK  ADMIN  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html");  //or ../welcome_landing.php")
    exit();
}
//if not a ADMIN **CHECK ROLE   (should only allow admin access here)
if ($_SESSION["userRole"] != "Admin") {
    header("Location: ../welcome_landing.php"); //or admin/admin_panel if role is admin
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Admins"; 
}

//---------DB CONNECTION---------------
/* reuse db connection w/error check --use conn for queries */
require_once '../include/dbconnect.php'; 
?>

<?php

//---DELETE FUNCTIONALITY --- 
if(isset($_GET['sellerID'])){
    //if -->  delete button clicked -- gets +sets the sellerID
    $sellerID = $_GET['sellerID'];
    $delete_seller_sql = "DELETE FROM sellers where sellerID='$sellerID' ";
    $seller_data = mysqli_query($conn, $delete_seller_sql);
    if($seller_data){
        header("Location: admin_view_sellers.php"); //if successful delete - send user to same place
    }
}
//-------------------------------fin delete--------------
//---UPDATE FUNCTIONALITY --- on admin_update_seller.php page
//no search

/* GET ALL SELLERS  */
// -- VIEW ALL SELLERS
$sql_all_sellers = "SELECT * FROM sellers";
$all_sellers_result = mysqli_query($conn, $sql_all_sellers);

//error handling -- if unsuccessful query for all sellers
if (!$all_sellers_result) {
    die("All Seller Query Error: ".mysqli_error($conn));
}
/* ===================================================== */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin: Sellers</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css">
    <link rel="stylesheet" href="admin_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->
>
    <style>
        /* =======================ADMIN VIEW SELLERS PAGE================*/
        /* all above layout repeats throughout the panel pages */
        /* table class="admin_table_sellers" */
        .admin_table_sellers {
            border: 3px solid black;
            margin-top: 35px;
        }

        /* NOT WORKING: (tr table row) TABLE HEADER ROW (th)
        .admin_table_sellers>tr>th {} 
        .admin_table_sellers>tr>th { */
        th {
            background: #2f84d9;
            font-weight: bold;
            text-align: center;
            padding: 9px;
            

        }
    
        td {
            text-align: center;
            padding: 10px 5px;  //top/bottom  , left/right
        }

        /* ===================ADMIN UPDATE/DELETE SELLERS PAGE==============*/
        /* =======DELETE SELLERS ======== */
        .panel_delete_btn {
            border-radius: 15px;
            background: red;
            padding: 8px;
        }
        .panel_delete_btn:hover {
            background-color: darkred;
        }

        /* =======UPDATE SELLERS ======== */
        .panel_update_btn {
            border-radius: 15px;
            background: orange;
            padding: 8px;
        }
        .panel_update_btn:hover {
            background-color: darkorange;
        }
    </style>

</head>

<body>

    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="/SpazaShapDraft2/images/logoSpazaShap.png" alt="Spaza Shap Logo">
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>

            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="adminPanelContainer">

            <!-- Admin panel sidebar (left shows functionality within ul>li) -->
            <div class="adminPanelSidebar">
                <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
                <li><a href="../welcome_landing.php">
                        <!-- Logo -->
                        <div class="logoSpazaShapPanel">
                            <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                            style="align-content:center;"> 
                        </div>
                    </a>
                </li>
                <h2>SpazaShap Admin</h2>
                <ul>
                    <li>
                        <a href="admin_panel.php">Admin Panel</a>
                    </li>
                    <li>
                        <a href="admin_view_buyers.php">Buyers</a>
                    </li>
                    <li>
                        <a href="admin_view_sellers.php">Sellers</a>
                    </li>
                    <li>
                        <a href="admin_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="admin_view_orders.php">Orders</a>
                    </li>
                </ul>
            </div>


            <div class="adminContentRight">
                <h1> Admin Panel: All Sellers</h1>
                <table class="admin_table_sellers">
                    <!-- Table Row -- for headers -->
                    <tr>
                        <th>Email</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Phone Number</th>
                        <th>Address</th>

                        <th>Delete</th>
                        <th>Update</th>
                    </tr>

                    <?php
                    $result = $all_sellers_result; /* TESTER before adding search */

                    if ($result && mysqli_num_rows($result) > 0) {
                        while ($sellerRow = mysqli_fetch_assoc($result)) {
                    ?>

                    <!-- Table row for Data (7 headers thus 7 data (incl del update) -->
                    <!-- sellerEmail, sellerFirstName, sellerLastName, 
                    sellerPhoneNumber, sellerAddress   ++++    Delete, Update -->
                    <tr>
                        <td><?php echo $sellerRow['sellerEmail'] ?></td>
                        <td><?php echo $sellerRow['sellerFirstName'] ?></td>
                        <td><?php echo $sellerRow['sellerLastName'] ?></td>
                        <td><?php echo $sellerRow['sellerPhoneNumber'] ?></td>
                        <td><?php echo $sellerRow['sellerAddress'] ?></td>

                        <!-- DELETE -->
                        <td>
                            <a onclick="return confirm('Are you sure you want to delete seller?');" 
                            class="panel_delete_btn"  
                            href="admin_view_sellers.php?sellerID=<?php echo $sellerRow['sellerID']?>">DELETE</a>
                        </td>

                        <!-- UPDATE -->
                        <td>
                            <a class="panel_update_btn" href="admin_update_seller.php?sellerID=<?php echo $sellerRow['sellerID']?>">UPDATE</a>
                        </td>
                    </tr>
                            
                    <?php }
                    } else {
                        echo "<p>No Sellers found.</p>";
                    }
                    ?>
                </table>
                <br><br><br><br>
            </div>

        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>