<!-- Levannah Kitshoff - 4 June 
admin_view_buyers.php -->
<?php
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  ADMIN  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html");  //or ../welcome_landing.php")
    exit();
}
//if not a ADMIN **CHECK ROLE   (should only allow admin access here)
if ($_SESSION["userRole"] != "Admin") {
    header("Location: ../welcome_landing.php"); //or admin/admin_panel if role is admin
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Admins"; //maybe give a message ???
}

//---------DB CONNECTION---------------
/* reuse db connection w/error check --use conn for queries */
require_once '../include/dbconnect.php'; 

//---DELETE FUNCTIONALITY --- 
if(isset($_GET['buyerID'])){
    //if -->  delete button clicked -- gets +sets the buyerID
    $buyerID = $_GET['buyerID'];
    $delete_buyer_sql = "DELETE FROM buyers where buyerID='$buyerID' ";
    $buyer_data = mysqli_query($conn, $delete_buyer_sql);
    if($buyer_data){
        header("Location: admin_view_buyers.php"); //if successful delete - send user to same place
    }
}
//-------------------fin delete------------------ :)

//---UPDATE FUNCTIONALITY --- on admin_update_seller.php page  
//---no search 

/* -- SQL: VIEW ALL BUYERS ----- */
$sql_all_buyers = "SELECT * FROM buyers";
$all_buyers_result = mysqli_query($conn, $sql_all_buyers);

//error handling -- if unsuccessful query for all buyers
if (!$all_buyers_result) {
    die("All Buyer Query Error: ".mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin: Buyers</title>

    <link rel="stylesheet" href="../styleV2.css "> 
    <link rel="stylesheet" href="admin_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->

    <style>
        /* =======================ADMIN VIEW BUYERS PAGE================*/
        /* all above layout repeats throughout the panel pages */

        /* table class="admin_table_buyers" */
        .admin_table_buyers {
            border: 3px solid black;
            margin-top: 35px;
        }

        th {
            background: #2f84d9;
            font-weight: bold;
            text-align: center;
            padding: 9px;
        }
        
        td {
            text-align: center;
            padding: 10px 5px;  //top/bottom  , left/right
        }

        /* ===================ADMIN UPDATE/DELETE BUYERS PAGE==============*/
        /* =======DELETE BUYERS ======== */
        .panel_delete_btn {
            border-radius: 15px;
            background: red;
            padding: 8px;
        }
        .panel_delete_btn:hover {
            background-color: darkred;
        }

        /* =======UPDATE BUYERS ======== */   
        .panel_update_btn {
            border-radius: 15px;
            background: orange;
            padding: 8px;
        }
        .panel_update_btn:hover {
            background-color: darkorange;
        }

    </style>
</head>

<body>
    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo">
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="adminPanelContainer">

            <!-- Admin panel sidebar (left shows functionality within ul>li) -->
            <div class="adminPanelSidebar">
                <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
                <li><a href="../welcome_landing.php">
                        <!-- Logo -->
                        <div class="logoSpazaShapPanel">
                            <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                            style="align-content:center;"> 
                        </div>
                    </a>
                </li>

                <h2>SpazaShap Admin</h2>
                <ul>
                    <li>
                        <a href="admin_panel.php">Admin Panel</a>
                    </li>
                    <li>
                        <a href="admin_view_buyers.php">Buyers</a>
                    </li>
                    <li>
                        <a href="admin_view_sellers.php">Sellers</a>
                    </li>
                    <li>
                        <a href="admin_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="admin_view_orders.php">Orders</a>
                    </li>
                </ul>

            </div>


            <div class="adminContentRight">
                <h1> Admin Panel: All Buyers</h1>

                <table class="admin_table_buyers">
                    <!-- Table Row -- for headers -->
                    <tr>
                        <!-- <th>Buyer ID</th> -->
                        <th>Email</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Phone Number</th>
                        <th>Address</th>
                        <th>Delete</th>
                        <th>Update</th>
                    </tr>

                    <?php
                    $result = $all_buyers_result; /*  before adding search */

                    if ($result && mysqli_num_rows($result) > 0) {
                        while ($buyerRow = mysqli_fetch_assoc($result)) {
                    ?>
                    <!-- Table row for Data (7 headers thus 7 data (incl del update) -->
                    <!-- buyerEmail, buyerFirstName, buyerLastName, 
                    buyerPhoneNumber, buyerAddress   ++++    Delete, Update -->
                    <tr>
                        <td><?php echo $buyerRow['buyerEmail'] ?></td>
                        <td><?php echo $buyerRow['buyerFirstName'] ?></td>
                        <td><?php echo $buyerRow['buyerLastName'] ?></td>
                        <td><?php echo $buyerRow['buyerPhoneNumber'] ?></td>
                        <td><?php echo $buyerRow['buyerAddress'] ?></td>

                        <!-- DELETE -->
                        <td>
                            <a onclick="return confirm('Are you sure you want to Delete Buyer?');" 
                            class="panel_delete_btn"  
                            href="admin_view_buyers.php?buyerID=<?php echo $buyerRow['buyerID']?>">DELETE</a>
                        </td>

                        <!-- UPDATE -->
                        <td>
                            <a class="panel_update_btn" 
                            href="admin_update_buyer.php?buyerID=<?php echo $buyerRow['buyerID']?>">UPDATE</a>
                        </td>
                    </tr>
                            
                    <?php }
                    } else {
                        echo "<p>No Buyers found.</p>";
                    }
                    ?>
                </table>
                <br><br><br><br><br><br>
            </div>
            
        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>