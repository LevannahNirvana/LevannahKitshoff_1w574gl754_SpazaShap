<?php
//Levannah Kitshoff - May 2025 
//admin_update_buyer.php

//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  ADMIN  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html"); //or login.html
    exit();
}

//if not a ADMIN **CHECK ROLE   (should only allow admin access here)
if ($_SESSION["userRole"] != "Admin") {
    header("Location: ../welcome_landing.php"); //or admin/admin_panel 
    exit(); //stop script after redirection
    //maybe give a message ???
    echo "Restricted Functionality - Only Allowed For Admins";
}

//---------DB CONNECTION---------------
/*reuse db connection w/ error check --use conn for queries */
require_once '../include/dbconnect.php';
//---------------------------------------

//------- SQL for displaying current existing Buyer data ---------
//BUYER ID  (FROM PREV PAGE OVER TO THIS PAGE) & Fetch buyer from DB
if (!isset($_GET['buyerID'])) {
    die("Error: Buyer ID not provided.");
}
$buyerID = $_GET['buyerID'];
$sql_select_buyer = "SELECT * FROM buyers WHERE buyerID = '$buyerID'";
$select_buyer_result = mysqli_query($conn, $sql_select_buyer);
$buyerRow = mysqli_fetch_assoc(($select_buyer_result));
//------------------------------------------------------------------


//===============IF SUBMIT UPDATE PRODUCT BUTTON CLICKED=============
if (isset($_POST['updateBuyerSubmitBtn'])) {
    /* if ($_SERVER["REQUEST_METHOD"] == "POST") { */

    //============GET UPDATE FORM DATA===================
    //buyers ---- to show for update 
    //----- buyerEmail, buyerFirstName, buyerLastName, buyerPhoneNumber, buyerAddress

    //============GET AND VALIDATE DATA===================
    $email = trim($_POST['buyerEmail']);
    /* $password = trim($_POST['password']); */
    $firstName = trim($_POST['buyerFirstName']);
    $lastName = trim($_POST['buyerLastName']);
    $phoneNumber = trim($_POST['buyerPhoneNumber']);
    $address = trim($_POST['buyerAddress']);
    //further sanitization --> 

    if (empty($email) || empty($firstName) || empty($lastName) || empty($phoneNumber) || empty($address)) {
        die("ERROR: All fields are required");
    }

    //Validate email for all user role types
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("ERROR: Invalid Email Format (SS Validation)");
        //die or echo --- die --stops execution (will not continue but sends err message to user)
    }

    //============= SQL UPDATE ===================
    //buyerEmail, buyerFirstName, buyerLastName, buyerPhoneNumber, buyerAddress
    $sql_update_buyer = "UPDATE buyers 
    SET buyerEmail = '$email' ,
    buyerFirstName = '$firstName', 
    buyerLastName = '$lastName',
    buyerPhoneNumber = '$phoneNumber', 
    buyerAddress = '$address'
    WHERE buyerID = '$buyerID'";

    $update_data = mysqli_query($conn, $sql_update_buyer);

    //redirect back to admin_view_buyers  (after buyer update)
    if ($update_data) {
        header("Location: admin_view_buyers.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Update Product</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css">
    <link rel="stylesheet" href="admin_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->

    <style>
        /* ---------------------------------------------------------- */
        .adminFormUpdateBuyer {justify-content: center;}
        /*-----------------------------------------------------------*/
        .form_area_div {padding: 8px;}
        .form_area_div>label {
            width: 150px;
            display: inline-block;
        }
        .form_area_div>input[type='text'] {
            padding: 10px;
            width: 30%;/* same weidth as others (inputs) */
            resize: vertical;/* only adjust height of element */
            box-sizing: border-box;
        }
        .form_area_div>textarea {
            height: 80px;/* larger starting height */
            width: 30%;/* same weidth as others (inputs) */
        }

        /* ================================ */
        /* ---UPDATE BUYER BUTTON--- */
        .form_area_div>#updateBuyerSubmitBtn {
            background-color: blue;
            width: 150px;
        }
        .form_area_div>#updateBuyerSubmitBtn:hover {background-color: dodgerblue;}

        /* ---CANCEL UPDATE BUYER BUTTON--- */
        .form_area_div>a>#updateBuyerCancelBtn {
            background-color: red;
            width: 150px;
        }
        .form_area_div>a>#updateBuyerCancelBtn:hover {background-color: darkred;}

        /* ================================ */
    </style>
</head>

<body>
    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo">
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="adminPanelContainer">
            <!-- Admin panel sidebar (left shows functionality within ul>li) -->
            <div class="adminPanelSidebar">
                <!-- Logo -->
                <div class="logoSpazaShapPanel">
                    <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                    style="align-content:center;">
                </div>
                <h2>SpazaShap Admin</h2>

                <ul>
                    <li>
                        <a href="admin_panel.php">Admin Panel</a>
                    </li>
                    <li>
                        <a href="admin_view_buyers.php">Buyers</a>
                    </li>
                    <li>
                        <a href="admin_view_sellers.php">Sellers</a>
                    </li>
                    <li>
                        <a href="admin_view_products.php">Products</a> 
                    </li>
                    <li>
                        <a href="admin_view_orders.php">Orders</a>
                    </li>
                </ul>
            </div>

            <div class="adminContentRight">
                <h2> Admin Update Buyer</h2>
                <form class="adminFormUpdateBuyer"
                    action="" method="POST"
                    enctype="multipart/form-data">
                    <!-- action="admin_update_buyer.php" or empty --same thing  -->

                    <!--buyerEmail, buyerFirstName, buyerLastName, buyerPhoneNumber, buyerAddress -->
                    <!-- emailError , lastNameError ,   phoneNumberError ,  addressError -->
                    <!-- buyerRow -->

                    <!--buyerEmail-->
                    <div class="form_area_div">
                        <label for="buyerEmail">Buyer Email:</label>
                        <input type="text" name="buyerEmail" id="buyerEmail" 
                        placeholder="e.g. john@spaza.com"
                            value="<?php echo $buyerRow['buyerEmail'] ?>">
                        <!-- <span id="emailError" class="error"></span> -->
                    </div>

                    <!--buyerFirstName-->
                    <div class="form_area_div">
                        <label for="buyerFirstName">Buyer First Name:</label>
                        <input type="text" name="buyerFirstName" id="buyerFirstName" 
                        placeholder="e.g. John"
                            value="<?php echo $buyerRow['buyerFirstName'] ?>">
                        <!-- <span id="firstNameError" class="error"></span> -->
                    </div>

                    <!--buyerLastName-->
                    <div class="form_area_div">
                        <label for="buyerLastName">Buyer Last Name:</label>
                        <input type="text" name="buyerLastName" id="buyerLastName" 
                        placeholder="e.g. Johnson"
                            value="<?php echo $buyerRow['buyerLastName'] ?>">
                        <!-- <span id="lastNameError" class="error"></span> -->
                    </div>

                    <!--buyerPhoneNumber-->
                    <div class="form_area_div">
                        <label for="buyerPhoneNumber">Buyer Phone Number:</label>
                        <input type="text" name="buyerPhoneNumber" id="buyerPhoneNumber" 
                        placeholder="e.g. 0811111111"
                            value="<?php echo $buyerRow['buyerPhoneNumber'] ?>">
                        <!-- <span id="phoneNumberError" class="error"></span> -->
                    </div>

                    <!-- buyerAddress -->
                    <div class="form_area_div">
                        <label for="buyerAddress">Buyer Address:</label>
                        <input type="text" name="buyerAddress" id="buyerAddress" 
                        placeholder="e.g. 11 Long Drive.."
                            value="<?php echo $buyerRow['buyerAddress'] ?>">
                        <!-- <span id="addressError" class="error"></span> -->
                    </div>

                    <!--  -- -- -- -- -- -- -- -- -- -- -- -- -- --  -- -- -- -- -- -- -- -- -->
 
                    <!--buttons submit & cancel-->
                    <div class="form_area_div">
                        <button id="updateBuyerSubmitBtn" type="submit" name="updateBuyerSubmitBtn" 
                        value="Update buyer"><b>Update Buyer</b></button>
                        <a href="admin_view_buyers.php">
                            <button id="updateBuyerCancelBtn" type="button" name="updateBuyerCancelBtn">
                                <b>Cancel</b>
                            </button>
                        </a>
                    </div>
                </form>

            </div>
        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>