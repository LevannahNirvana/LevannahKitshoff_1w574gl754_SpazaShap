<?php
//Levannah Kitshoff - April 2025 
//admin_update_seller.php
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  ADMIN  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html"); //or login.html
    exit();
}
//if not a ADMIN **CHECK ROLE   (should only allow admin access here)
if ($_SESSION["userRole"] != "Admin") {
    header("Location: ../welcome_landing.php"); //or admin/admin_panel 
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Admins";
}
?>

<?php
//---------DB CONNECTION---------------
/*reuse db connection w/ error check --use conn for queries */
require_once '../include/dbconnect.php';
//---------------------------------------

//------- SQL for displaying current existing seller data ---------
//SELLER ID  (FROM PREV PAGE OVER TO THIS PAGE) & Fetch seller from DB
if (!isset($_GET['sellerID'])) {
    die("Error: Seller ID not provided.");
}
$sellerID = $_GET['sellerID'];
$sql_select_seller = "SELECT * FROM sellers WHERE sellerID = '$sellerID'";
$select_seller_result = mysqli_query($conn, $sql_select_seller);
$sellerRow = mysqli_fetch_assoc(($select_seller_result));
//------------------------------------------------------------------


//===============IF SUBMIT UPDATE PRODUCT BUTTON CLICKED=============
if (isset($_POST['updateSellerSubmitBtn'])) {
    /* if ($_SERVER["REQUEST_METHOD"] == "POST") { */

    //============GET UPDATE FORM DATA===================
    //sellers ---- to show for update ----- sellerEmail, sellerFirstName, sellerLastName, sellerPhoneNumber, sellerAddress

    //============GET AND VALIDATE DATA===================
    $email = trim($_POST['sellerEmail']);
    /* $password = trim($_POST['password']); */
    $firstName = trim($_POST['sellerFirstName']);
    $lastName = trim($_POST['sellerLastName']);
    $phoneNumber = trim($_POST['sellerPhoneNumber']);
    $address = trim($_POST['sellerAddress']);
    //further sanitization --> 

    if (empty($email) || empty($firstName) || empty($lastName) || empty($phoneNumber) || empty($address)) {
        die("ERROR: All fields are required");
    }

    //Validate email for all user role types
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("ERROR: Invalid Email Format (SS Validation)");
        //die or echo --- die --stops execution (will not continue but sends err message to user)
    }

    //============= SQL UPDATE ===================
    //sellerEmail, sellerFirstName, sellerLastName, sellerPhoneNumber, sellerAddress
    $sql_update_seller = "UPDATE sellers 
    SET sellerEmail = '$email' ,
    sellerFirstName = '$firstName', 
    sellerLastName = '$lastName',
    sellerPhoneNumber = '$phoneNumber', 
    sellerAddress = '$address'
    WHERE sellerID = '$sellerID'";

    $update_data = mysqli_query($conn, $sql_update_seller);

    //redirect back to admin_view_sellers  (after seller update)
    if ($update_data) {
        header("Location: admin_view_sellers.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Update Product</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css"> <!-- ../styleV2.css -->
    <link rel="stylesheet" href="admin_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->

    <style>
        .adminContentRight {
            border: solid 1pt black;
            width: 80%; /*  added to fill more of content */
            margin-top: 10px;
            padding: 10px;
        }

        /* ---------------------------------------------------------- */
        .adminFormUpdateSeller {
            justify-content: center;
        }
        /* ---------------------------------------------------------- */

        .form_area_div {
            padding: 8px;
        }
        .form_area_div>label {
            width: 150px;
            display: inline-block;
        }

        .form_area_div>input[type='text'] {
            padding: 10px;
            width: 30%;/* same weidth as others (inputs) */
            resize: vertical;/* only adjust height of element */
            box-sizing: border-box;
        }

        .form_area_div>textarea {
            height: 80px;/* larger starting height */
            width: 30%;/* same weidth as others (inputs) */
        }

        /* ================================ */
        /* ---UPDATE SELLER BUTTON--- */
        .form_area_div>#updateSellerSubmitBtn {
            background-color: blue;
            width: 150px;
        }

        .form_area_div>#updateSellerSubmitBtn:hover {
            background-color: dodgerblue;
        }

        /* ---CANCEL UPDATE SELLER BUTTON--- */
        .form_area_div>a>#updateSellerCancelBtn {
            background-color: red;
            width: 150px;
        }
        .form_area_div>a>#updateSellerCancelBtn:hover {
            background-color: darkred;
        }
        /* ================================ */
    </style>
</head>

<body>
    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="adminPanelContainer">
            <!-- Admin panel sidebar (left shows functionality within ul>li) -->
            <div class="adminPanelSidebar">
                <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
                <li><a href="../welcome_landing.php">
                        <!-- Logo -->
                        <div class="logoSpazaShapPanel">
                            <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                            style="align-content:center;"> 
                        </div>
                    </a>
                </li>
                <h2>SpazaShap Admin</h2>
                <ul>
                    <li>
                        <a href="admin_panel.php">Admin Panel</a>
                    </li>
                    <li>
                        <a href="admin_view_buyers.php">Buyers</a>
                    </li>
                    <li>
                        <a href="admin_view_sellers.php">Sellers</a>
                    </li>
                    <li>
                        <a href="admin_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="admin_view_orders.php">Orders</a>
                    </li>
                </ul>

            </div>


            <div class="adminContentRight">
                <h2> Admin Update Seller</h2>
                <form class="adminFormUpdateSeller"
                    action="" method="POST"
                    enctype="multipart/form-data">
                    <!-- action="admin_update_seller.php" or empty --same thing  -->

                    <!--sellerEmail, sellerFirstName, sellerLastName, sellerPhoneNumber, sellerAddress -->
                    <!-- emailError , lastNameError ,   phoneNumberError ,  addressError -->
                    <!-- sellerRow -->

                    <!--sellerEmail-->
                    <div class="form_area_div">
                        <label for="sellerEmail">Seller Email:</label>
                        <input type="text" name="sellerEmail" id="sellerEmail" 
                        placeholder="e.g. john@spaza.com"
                            value="<?php echo $sellerRow['sellerEmail'] ?>">
                        <!-- <span id="emailError" class="error"></span> -->
                    </div>

                    <!--sellerFirstName-->
                    <div class="form_area_div">
                        <label for="sellerFirstName">Seller First Name:</label>
                        <input type="text" name="sellerFirstName" id="sellerFirstName" 
                        placeholder="e.g. John"
                            value="<?php echo $sellerRow['sellerFirstName'] ?>">
                        <!-- <span id="firstNameError" class="error"></span> -->
                    </div>

                    <!--sellerLastName-->
                    <div class="form_area_div">
                        <label for="sellerLastName">Seller Last Name:</label>
                        <input type="text" name="sellerLastName" id="sellerLastName" 
                        placeholder="e.g. Johnson"
                            value="<?php echo $sellerRow['sellerLastName'] ?>">
                        <!-- <span id="lastNameError" class="error"></span> -->
                    </div>

                    <!--sellerPhoneNumber-->
                    <div class="form_area_div">
                        <label for="sellerPhoneNumber">Seller Phone Number:</label>
                        <input type="text" name="sellerPhoneNumber" id="sellerPhoneNumber" 
                        placeholder="e.g. 0811111111"
                            value="<?php echo $sellerRow['sellerPhoneNumber'] ?>">
                        <!-- <span id="phoneNumberError" class="error"></span> -->
                    </div>

                    <!-- sellerAddress -->
                    <div class="form_area_div">
                        <label for="sellerAddress">Seller Address:</label>
                        <input type="text" name="sellerAddress" id="sellerAddress" 
                        placeholder="e.g. 11 Long Drive.."
                            value="<?php echo $sellerRow['sellerAddress'] ?>">
                        <!-- <span id="addressError" class="error"></span> -->
                    </div>

                    <!--buttons submit & cancel-->
                    <div class="form_area_div">
                        <button id="updateSellerSubmitBtn" type="submit" name="updateSellerSubmitBtn" 
                        value="Update seller"><b>Update Seller</b></button>
                        <a href="admin_view_sellers.php">
                            <button id="updateSellerCancelBtn" type="button" name="updateSellerCancelBtn">
                                <b>Cancel</b>
                            </button>
                        </a>
                    </div>
                </form>

            </div>
        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>