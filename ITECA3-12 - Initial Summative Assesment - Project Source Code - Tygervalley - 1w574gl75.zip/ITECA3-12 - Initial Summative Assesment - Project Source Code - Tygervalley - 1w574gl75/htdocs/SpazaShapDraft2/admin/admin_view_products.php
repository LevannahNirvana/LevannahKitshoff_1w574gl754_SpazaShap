<?php
/* Levannah Kitshoff - 24 May 2025 
admin_view_products.php */
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  ADMIN  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html");  
    exit();
}

//if not a ADMIN **CHECK ROLE   (should only allow admin access here)
if ($_SESSION["userRole"] != "Admin") {
    header("Location: ../welcome_landing.php"); //or admin/admin_panel if role is admin
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Admins";
}

//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once '../include/dbconnect.php'; 
?>

<?php

//---DELETE FUNCTIONALITY ADDED--- works with confirmation   24 May 2025
if (isset($_GET['productID'])) {
    //if -->  delete button clicked -- gets +sets the productID
    $productID = $_GET['productID'];
    $delete_product_sql = "DELETE FROM products where productID='$productID' ";
    $product_data = mysqli_query($conn, $delete_product_sql);
    if ($product_data) {
        header("Location: admin_view_products.php"); //if successful - send user to same place
    }
}
//-------------fin delete------------------

//---UPDATE FUNCTIONALITY --- on admin_update_product.php page
/* no search */

/* =======TESTER before search added 24 May =========== */
//(No Search Button Clicked) -- VIEW ALL PRODUCTS with CATEGORY NAME
$sql_all_base_products = "SELECT products.*, product_categories.categoryName FROM products 
LEFT JOIN product_categories ON products.categoryID = product_categories.categoryID";
$all_base_products_result = mysqli_query($conn, $sql_all_base_products);

//error handling -- if unsuccessful query for all products
if (!$all_base_products_result) {
    die("All Product Query Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin: Products</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css">
    <link rel="stylesheet" href="admin_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->
    <style>
        /* =======================ADMIN VIEW PRODUCTS PAGE================*/
        /* all above layout repeats throughout the panel pages */

        /* table class="admin_table_products" */
        .admin_table_products {
            border: 3px solid black;
            margin-top: 35px;
        }

        /* NOT WORKING: (tr table row) TABLE HEADER ROW (th)
        .admin_table_products>tr>th {} 
        .admin_table_products>tr>th { */
        th {
            background: #2f84d9;
            font-weight: bold;
            text-align: center;
            padding: 9px;


        }
        td {
            text-align: center;
            padding: 5px;
        }

        /* ===================ADMIN UPDATE/DELETE PRODUCTS PAGE==============*/
        /* =======DELETE PRODUCTS ======== */
        .panel_delete_btn {
            border-radius: 15px;
            background: red;
            padding: 8px;
        }

        .panel_delete_btn:hover {
            background-color: darkred;
        }

        /* =======UPDATE PRODUCTS ======== */
        .panel_update_btn {
            border-radius: 15px;
            background: orange;
            padding: 8px;
        }

        .panel_update_btn:hover {
            background-color: darkorange;
        }
    </style>
</head>

<body>
    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="adminPanelContainer">

            <!-- Admin panel sidebar (left shows functionality within ul>li) -->
            <div class="adminPanelSidebar">
                <!-- Logo -->
                <div class="logoSpazaShapPanel">
                    <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                    style="align-content:center;">
                </div>
                <h2>SpazaShap Admin</h2>
                <ul>
                    <li>
                        <a href="admin_panel.php">Admin Panel</a>
                    </li>
                    <li>
                        <a href="admin_view_buyers.php">Buyers</a>
                    </li>
                    <li>
                        <a href="admin_view_sellers.php">Sellers</a>
                    </li>
                    <li>
                        <a href="admin_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="admin_view_orders.php">Orders</a>
                    </li>
                </ul>

            </div>


            <div class="adminContentRight">
                <h1> Admin Panel: All Products</h1>

                <table class="admin_table_products">
                    <!-- Table Row -- for headers -->
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Stock Quantity</th>
                        <th>Category</th>
                        <th>Delete</th>
                        <th>Update</th>
                    </tr>

                    <?php
                    $result = $all_base_products_result; 

                    if ($result && mysqli_num_rows($result) > 0) {
                        while ($productRow = mysqli_fetch_assoc($result)) {
                    ?>

                    <!--Image, Name,Description, Price, StockQuantity   ... categoryID select not table-->
                    <!-- Table row for Data (5 headers thus 5 data) -->
                    <tr>
                        <td>
                            <!-- width 100 px & height style needed here! -->
                            <img class="admin_productImage" alt="product image" width='100px' 
                            height='100px' 
                            src="../product_images/<?php echo htmlspecialchars($productRow['productImageSource']) ?>">
                        </td>
                        <td><?php echo $productRow['productName'] ?></td>
                        <td><?php echo $productRow['productDescription'] ?></td>
                        <td><?php echo $productRow['productPrice'] ?></td>
                        <td><?php echo $productRow['productStockQuantity'] ?></td>
                        <!-- product_categories joined to products -->
                        <td><?php echo htmlspecialchars($productRow['categoryName']) ?></td>

                        <!-- DELETE -->
                        <td>
                            <a onclick="return confirm('Are you sure you want to Delete Product?');" class="panel_delete_btn" href="admin_view_products.php?productID=<?php echo $productRow['productID'] ?>">DELETE</a>
                            <!-- id will come from db -->
                        </td>

                        <!-- UPDATE -->
                        <td>
                            <a class="panel_update_btn" href="admin_update_product.php?productID=<?php echo $productRow['productID'] ?>">UPDATE</a>

                        </td>
                    </tr>
                            
                    <?php }
                    } else {
                        echo "<p>No products found.</p>";
                    }
                    ?>
                </table>
                <br><br>
            </div>

        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>