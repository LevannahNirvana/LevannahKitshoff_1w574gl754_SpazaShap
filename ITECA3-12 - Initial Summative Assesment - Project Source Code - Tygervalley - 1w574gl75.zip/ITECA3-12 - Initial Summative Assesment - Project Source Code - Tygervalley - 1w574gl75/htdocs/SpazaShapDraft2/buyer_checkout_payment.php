<!-- Levannah Kithsoff  - June 2025
buyer_checkout_payment.php 
-->
<?php
session_start(); //Start session

//CHECK SESSION SET IN SESSIONS (orderID and finalTotal  --- for payment ) 
if (!isset($_SESSION["orderID"]) || !isset($_SESSION["finalTotal"])) {
    header("Location: buyer_cart.php"); //redirect to cart if not orderID or finalTotal
    exit();
} 

//GET VALUES from SESSIONs  
//--- orderID, baseTotal (productsTotal), shippingCost, finalTotal
$orderID = $_SESSION["orderID"];
$baseTotal = $_SESSION["baseTotal"];
$shippingCost = $_SESSION["shippingCost"];
$finalTotal = $_SESSION["finalTotal"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Buyer Checkout - Payment</title>
    <link rel="stylesheet" href="styleV2.css">
    <style>
        /*payment container style*/
        .payment_container {
            max-width: 400px;
            margin: 40px auto;
            padding: 30px;
            border: 2px solid black;
            border-radius: 10px;
            background-color: #f9f9f9;
        }

        /*payment container input style for text and submit*/
        .payment_container input[type="text"], 
        .payment_container input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
        }

        .payment_container input[type="submit"] {
            background:  #3d3e3d; 
            color: white;
            border: solid #c3c0c0; 
            border-radius: 50px;
            cursor: pointer;
            
            /* width: 100%; */
            /* padding: 10px;
            margin: 1rem 1rem; */
        }

        /*totals container style*/
        .totals_container {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="images/logoSpazaShap.png" alt="Spaza Shap Logo">
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>
        </nav>
    </header>

        <main>
        <div class="payment_container">
            <h2>Complete the Order Payment</h2>

            <!-- Totals Container - subtotal, delivery/shipping cost, final cost -->  
            <div class="totals_container">
                <p>Subtotal: R<?php echo number_format($baseTotal, 2); ?></p>
                <p>Delivery/Shipping Cost: R<?php echo number_format($shippingCost, 2); ?></p>
                <hr>
                <p><strong>Final Total: R<?php echo number_format($finalTotal, 2); ?></strong></p>
            </div>

            <!-- FORM for Payment Details --> 
            <form action="buyer_payment_success.php" method="POST">
                <!--hidden values- orderID, finalTotal in form-->
                <input type="hidden" name="orderID" value="<?php echo $orderID; ?>">
                <input type="hidden" name="finalTotal" value="<?php echo $finalTotal; ?>">

                <!-- User input -- cardNumber, expiry, cvv & submit --> 
                <label for="cardNumber">Card Number:</label>
                <input type="text" name="cardNumber" required placeholder="1234 5678 9012 3456">

                <label for="expiry">Expiry Date:</label>
                <input type="text" name="expiry" required placeholder="MM/YY">

                <label for="cvv">CVV:</label>
                <input type="text" name="cvv" maxlength="3" required placeholder="444">

                <!-- submit button - Confirm Payment-->
                <input type="submit" value="Confirm Payment"> 
            </form>
        </div>

    </main>
    <!-- FOOTER -->
    <?php include 'include/footer.php'; ?>
    <script></script>
</body>
</html>

