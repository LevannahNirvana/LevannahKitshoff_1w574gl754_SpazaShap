<?php
//if no session started yet... (for include) 
/* if (session_status() === PHP_SESSION_NONE) { */
    /* session_start(); */ //Start session
/* }  */

$_SESSION['userLoggedIn'] ?? null;
$_SESSION['userRole'] ?? null;
/* $userRole = $_SESSION['userRole'] ?? null; */
//Retrieve user email from session, if not set, it will be null (=Proves logged in)
?>

<nav class="navigationBar">

    <div class="leftNavigation">
        <!-- Clickable Logo & Text to redirect to Home / Welcome Landing Page -->
        <a href="welcome_landing.php">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>
        </a>

        <!-- Left Navigation Links (Home, Products, About) -->
        <ul class="navigationBarList leftNavLinks">
            <li><a href="welcome_landing.php">Home</a></li>
            <li><a href="view_all_products.php">Products</a></li> <!--Products - buy product (buyers)-->
            <li><a href="about.php">About</a></li>
        </ul>
    </div>

    <!-- Search Bar -->
    <div class="centerNavigation">
        <!-- <form class="searchForm" action="search_product.php" method="GET"> -->
        <form class="navSearchForm" action="view_all_products.php" method="GET">
            <input type="search" id="search" name="search" placeholder="Search for product...">
            <button class="navSearchButton" name="navSearchButton">Search</button>
        </form>
    </div>

    <!-- Right Navigation Links (Register Login) (Cart, Profile)   **removed profile for base model-->
    <div class="rightNavigation navigationBarList">
        <ul class="navigationBarList rightNavLinks">
        
                <!-- Guest User works :)  -->
                <?php if (!isset($_SESSION['userLoggedIn'])): {  ?>
                    <li><a href="nonUser_index.php" class="navButton">Register</a></li>
                    <li><a href="login.html" class="navButton">Login</a></li>
                <!-- admin vs buyer vs seller -->
                
                <!-- ADMIN -->
                <?php  }elseif ($_SESSION["userRole"] == "Admin"): { ?>
                    <li><a href="admin/admin_panel.php" class="navButton">Admin Panel </a></li>
                    <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                    <li><a href="logout.php" class="navButton">Logout</a></li>
      
                <!-- SELLER -->
                <?php  }elseif ($_SESSION["userRole"] == "Seller"): { ?>
                    <li><a href="seller/seller_panel.php" class="navButton">Seller Panel </a></li>
                    <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                    <li><a href="logout.php" class="navButton">Logout</a></li>

                <!-- BUYER (ELSE) -->
                <?php  }elseif ($_SESSION["userRole"] == "Buyer"): { ?>
                    <li><a href="cart.php" class="navButton">Cart</a></li>
                    <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                    <li><a href="logout.php" class="navButton">Logout</a></li>

            <?php } endif; ?>
        </ul>
    </div>
</nav>