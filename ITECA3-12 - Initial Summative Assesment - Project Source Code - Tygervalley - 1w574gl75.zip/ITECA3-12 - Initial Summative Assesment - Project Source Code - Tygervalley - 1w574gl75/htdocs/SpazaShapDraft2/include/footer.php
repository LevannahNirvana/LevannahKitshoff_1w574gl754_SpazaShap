<!-- Levannah Kitshoff - April 2025 
footer.php --> 
<footer class="footerContainer">
    <div class="leftFooter">
        <h5>Contact Us:</h5>
        <p>Email: spazashap@gmail.com</p>
        <p>Phone Number:  021 559 3939</p>
        <p>Address: 4 Lava Lane, Durbanville, Cape Town 7550</p>
    </div>

    <div class="centerFooter">
    <p> &#xa9 2025 SpazaShap </p>
    </div>

    <div class="rightFooter"></div>
</footer>