<?php
//Levannah Kitshoff - April 2025 
//dbconnect.php

    //================DATABASE========================
    //#1 DB Connection Variables
    $host = "localhost";
    $db_user = "root";
    $db_password = ""; //set to empty @ first
    $db_name = "spazashap_draft_db"; //DRAFT db


    //#2 DB CONNECT 
    $conn = mysqli_connect($host, $db_user, $db_password, $db_name);

    //#3 CHECK DB CONNECTION
    if (!$conn) {
        die("Error: SpazaShap Database Connection Failed ".mysqli_connect_error());
    }

?>