<!-- Levannah Kitshoff - June 2025 
        buyer_checkout.php
-->
<?php
//--------------- SESSIONS --------------
session_start();

//----------------- temp error debugging - help 
/* mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
error_reporting(E_ALL);
ini_set('display_errors', 1); */
//----------------------------------------------------

//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: login.html"); 
    exit();
}
//if not a BUYER **CHECK ROLE   (should only allow seller access here)
if ($_SESSION["userRole"] != "Buyer") {
    header("Location: welcome_landing.php");  
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Buyers";
}
?>

<?php
//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once 'include/dbconnect.php';

//-------- BUYER
$buyerEmail = $_SESSION["email"]; //session email for buyerEmail
$sql_buyerID = "SELECT buyerID FROM buyers WHERE buyerEmail = '$buyerEmail'";
$result_buyerID = mysqli_query($conn, $sql_buyerID);
$buyerRow = mysqli_fetch_assoc($result_buyerID);
$buyerID = $buyerRow["buyerID"]; //retrieved buyerID in DB with email 

//------FORM DATA ( delivery option, orderID (hidden))
$orderID = $_POST["orderID"]; //hidden data in form 
$deliveryOption = $_POST["deliveryOption"];  // 'pickup' or 'delivery'

//----- BASE TOTAL (sum of quantity * price at order time)  from --- order_products
$sql_product_total = "SELECT SUM(quantity * price_at_order_time) AS baseTotal
              FROM order_products
              WHERE orderID = '$orderID'";
$result_product_total = mysqli_query($conn, $sql_product_total);
$row_product_total = mysqli_fetch_assoc($result_product_total);

$baseTotal = $row_product_total["baseTotal"];
$shippingCost = 0; //initialize shippingCost to 0 

//CALCULATE SHIPPING COST (0 - pickup/collection ,   100 under R1000 , or 0 over R1000)
//Placed when NO shipping costs -- for seller to see to bring order
//Placed when YES shipping costs -- for seller to see to bring order (or Paid in once payment success)

//----- Calculate DELIVERY --- shipping and finalTotal 
if ($baseTotal < 1000 && $deliveryOption === "delivery") {
    $shippingCost = 100;
}
$finalTotal = $baseTotal + $shippingCost;

//---------PICKUP -- immediate placed (pay in store ) *Placed orders seen by Sellers to bring prods
if ($deliveryOption === "pickup") {
    //INSTANT finalization of orderDate and orderStatus --- for pickup
    $orderDate = date("Y-m-d");
    $orderStatus = "Placed"; 

    //Update Orders --- orderTotal, orderStatus, orderDate
    $sql_update = "UPDATE orders
                   SET orderTotal = '$finalTotal',
                       orderStatus = '$orderStatus',
                       orderDate = '$orderDate'
                   WHERE orderID = '$orderID' AND buyerID = '$buyerID'";

    if (mysqli_query($conn, $sql_update)) {
        header("Location: buyer_orders.php?success=pickup_checkout"); 
        //passed as get var --> success=pickup_checkout
        exit();
    } else {
        echo "Error updating order: ".mysqli_error($conn);
    }
//-----------DELIVERY  
} elseif ($deliveryOption === "delivery") {
    // DO NOT place order yet — go to payment page for order 
    //-- send orderID, finalTotal, shippingCost, baseTotal - to buyer_checkout_payment.php
    $_SESSION["orderID"] = $orderID;
    $_SESSION["finalTotal"] = $finalTotal;
    $_SESSION["shippingCost"] = $shippingCost;
    $_SESSION["baseTotal"] = $baseTotal;

    // Set deliveryOption in session --- for buyer_checkout_payment.php and buyer_payment_success.php
    $_SESSION["deliveryOption"] = "delivery";

    // Redirect to buyer_checkout_payment.php
    header("Location: buyer_checkout_payment.php");
    exit();
}
?>