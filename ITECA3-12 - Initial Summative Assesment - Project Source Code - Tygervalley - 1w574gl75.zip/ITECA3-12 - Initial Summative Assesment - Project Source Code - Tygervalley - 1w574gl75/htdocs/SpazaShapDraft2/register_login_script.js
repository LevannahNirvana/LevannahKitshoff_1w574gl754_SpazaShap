//Levannah Kitshoff - April/May 2025
//=====================REGISTER USERS  (BUYER/SELLER  & ADMIN)=================
//--------------------------BUYER/SELLER (REGISTER VALIDATION)---------------------------------------------
//JavaScript Validation for buyer_register.html page & seller_register.html 
function validateNonAdminRegisterForm() {

    //------------------- 1. get input values ------------------------
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value.trim();
    let firstName = document.getElementById("firstName").value.trim();
    let lastName = document.getElementById("firstName").value.trim();
    //Buyer/Seller Role Form Fields
    let phoneNumber = document.getElementById("phoneNumber").value.trim();
    let address = document.getElementById("address").value.trim();

    //---------------- 2. get error message elements (spans) -----------------
    let emailError = document.getElementById("emailError");
    let passwordError = document.getElementById("passwordError");
    let firstNameError = document.getElementById("firstNameError");
    let lastNameError = document.getElementById("lastNameError");

    //Buyer/Seller Role Form Fields - Errors
    let phoneNumberError = document.getElementById("phoneNumberError");
    let addressError = document.getElementById("addressError");

    //------3. clear previous errors ------
    emailError.innerHTML = "";
    passwordError.innerHTML = "";
    firstNameError.innerHTML = "";
    lastNameError.innerHTML = "";

    /* buyer/seller errors*/
    phoneNumberError.innerHTML = "";
    addressError.innerHTML = "";

    //4. -------------------- Validation-------------------
    //have to return a true or false  -- therefore have isValid
    let isValid = true;

    //***Validate Email -- If empty / === "" ... else if not match
    let emailRegPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (email === "") {
        emailError.innerHTML = "Email is Required";
        isValid = false; //false  -- prevent to submit
    } else if (!email.match(emailRegPattern)) {
        emailError.innerHTML = "Invalid Email Format";
        isValid = false;
    }

    //***Validate Password
    if (password === "") {
        passwordError.innerHTML = "Password is Required";
        isValid = false;
    } else if (password.length < 8) {
        passwordError.innerHTML = "Password must be a minimum of 8 characters long";
        isValid = false;
    }

    //***Validate First Name
    if (firstName === "") {
        firstNameError.innerHTML = "First Name is Required";
        isValid = false;
    }

    //***Validate Last Name
    if (lastName === "") {
        lastNameError.innerHTML = "Last Name is Required";
        isValid = false;
    }

    //-----------------USER ROLE & VALIDATE FORM FIELDS-----------------------------
    //------- VALIDATE BUYER/SELLER form field inputs -------
    //Validate Phone Number   
    if (phoneNumber === "") {
        phoneNumberError.innerHTML = "BUYER/SELLER: Phone Number is Required";
        isValid = false;

    }
    //possible regex to add for further phone number validation
    //***Validate Phone Number -- If empty / === "" ... else if not match
    let phoneRegPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (phoneNumber === "") {
        phoneNumberErrorError.innerHTML = "Phone Number is Required";
        isValid = false; //false  -- prevent to submit
    } else if (!phoneNumber.match(phoneRegPattern)) {
        phoneNumberErrorError.innerHTML = "Invalid Email Format";
        isValid = false;
    }
    /*
    format phone number: 
        Accepted: 
        (022)2222222
        (022) 222 2222
        000 0000 0000
        022-238-3833
    */


    //Validate Address
    if (address === "") {
        addressError.innerHTML = "BUYER/SELLER: Address is Required";
        isValid = false;
    }
    //

    return isValid;
}

//--------------------------------ADMIN (REGISTER VALIDATION)----------------------------------------------
//JavaScript Validation for admin_register.html page  
function validateAdminRegisterForm() {

    //------------------- 1. get input values ------------------------
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value.trim();
    let firstName = document.getElementById("firstName").value.trim();
    let lastName = document.getElementById("firstName").value.trim();
    //Admin Role Form Field
    let adminPassCode = document.getElementById("adminPassCode").value.trim();

    //---------------- 2. get error message elements (spans) -----------------
    let emailError = document.getElementById("emailError");
    let passwordError = document.getElementById("passwordError");
    let firstNameError = document.getElementById("firstNameError");
    let lastNameError = document.getElementById("lastNameError");

    let adminPassCodeError = document.getElementById("adminPassCodeError");

    //------3. clear previous errors ------
    emailError.innerHTML = "";
    passwordError.innerHTML = "";
    firstNameError.innerHTML = "";
    lastNameError.innerHTML = "";

    adminPassCodeError.innerHTML = "";

    //4. -------------------- Validation-------------------
    //have to return a true or false  -- therefore have isValid
    let isValid = true;

    //***Validate Email --- If empty / === "" ... else if not match pattern
    let emailRegPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (email === "") {
        emailError.innerHTML = "Email is Required";
        isValid = false; //false  -- prevent to submit
    } else if (!email.match(emailRegPattern)) {
        emailError.innerHTML = "Invalid Email Format";
        isValid = false;
    }

    //***Validate Password
    if (password === "") {
        passwordError.innerHTML = "Password is Required";
        isValid = false;
    } else if (password.length < 8) {
        passwordError.innerHTML = "Password must be a minimum of 8 characters long";
        isValid = false;
    }

    //***Validate First Name
    if (firstName === "") {
        firstNameError.innerHTML = "First Name is Required";
        isValid = false;
    }
    //***Validate Last Name
    if (lastName === "") {
        lastNameError.innerHTML = "Last Name is Required";
        isValid = false;
    }

    //------- VALIDATE ADMIN form field input -------
            //Validate Admin PassCode -- not empty -- (check actual match value in php)
            if (adminPassCode === "") {
                adminPassCodeError.innerHTML = "ADMIN: Admin Pass Code is Required";
                isValid = false;
            }

    return isValid;
}



//========================LOGIN VALIDATION=================================
function validateLoginForm() {
    //------------------- 1. get input values ------------------------
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value.trim();
    //note naming selectedUserRole
    let selectedUserRole = document.getElementById("userRoles").value.trim();

    //---------------- 2. get error message elements (spans) -----------------
    let emailError = document.getElementById("emailError");
    let passwordError = document.getElementById("passwordError");
    let userRoleError = document.getElementById("userRoleError");

    //------3. clear previous errors ------
    emailError.innerHTML = "";
    passwordError.innerHTML = "";
    userRoleError.innerHTML = "";

    //4. -------------------- Validation-------------------
    let isValid = true; //have to return a true or false  -- therefore have isValid

    //***Validate Email -- If empty / === "" ... else if not match pattern
    let emailRegPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (email === "") {
        emailError.innerHTML = "Email is Required";
        isValid = false; //false  -- prevent to submit
    } else if (!email.match(emailRegPattern)) {
        emailError.innerHTML = "Invalid Email Format";
        isValid = false;
    }

    //***Validate Password
    if (password === "") {
        passwordError.innerHTML = "Password is Required";
        isValid = false;
    }else if (password.length < 8) {
        passwordError.innerHTML = "Password must be a minimum of 8 characters long";
        isValid = false;
    }

    //Validate User Role --- "" to match the option value in each register page
    if (selectedUserRole === "") {
        userRoleError.innerHTML = "User Role is Required";
        isValid = false;
    }

    return isValid;   
}