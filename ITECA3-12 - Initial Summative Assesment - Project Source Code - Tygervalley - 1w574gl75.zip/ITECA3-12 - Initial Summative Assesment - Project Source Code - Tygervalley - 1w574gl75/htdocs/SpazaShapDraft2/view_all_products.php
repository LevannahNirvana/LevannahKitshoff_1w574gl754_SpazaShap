<?php
//Levannah Kitshoff - May 2025 
//View All Products (With Search Page)
//Start session
session_start();

//----------------------DATABASE CONNECTION----------------------
//------------- DATABASE CONNECT   *PROCEDURAL
//#1 DB Connection Variables & #2 DB CONNECT & #3 CHECK DB CONNECT 
require_once 'include/dbconnect.php';  
//works - inside same directory is include file - within it is dbconnect

//=====================================================================
//--------CATEGORIES (FETCH from DB TABLE) for select option ----------
$categoryQuery = mysqli_query($conn, "SELECT * FROM product_categories");
if (!$categoryQuery) {
    die("Category query failed: " . mysqli_error($conn));
}
//=====================================================================


//=====================================================================
//-------- QUERY PREP FOR VIEW ALL PRODUCTS & SEARCH

/* IF THERE IS A SEARCH FORM INPUT -- search for product  */
/* IF SOMEONE CLICK ON SEARCH BUTTON: 
   check name of button -- navSearchButton */
if (isset($_GET['navSearchButton'])) {
    $search_value = $_GET['search']; /* name of search input -- search */

    //search product --- name and description
    $sql_search_products = "SELECT * FROM products WHERE concat(productName, productDescription) LIKE '%$search_value%' ";

    $search_products_result = mysqli_query($conn, $sql_search_products);
    //error handling -- if unsuccessful search query for product
    if (!$search_products_result) {
        die("Product Search Query Error: " . mysqli_error($conn));
    }
    
} elseif (isset($_GET['mainSearchButton'])) {
    //MAIN SEARCH BUTTON (BOTTOM)
    $search_value = mysqli_real_escape_string($conn, $_GET['mainSearch'] ?? ''); //mainSearch value or none '' (sanitize)
    $selected_category = $_GET['productCategories']?? 'all'; //sanitize productCategories value or 'all'

    // --------SQL ALL PRODUCT SETUP (BASE)-------
    $sql_search_products = "SELECT * FROM products WHERE productStockQuantity > 0";

    // SEARCH FILTER (if has search value)
    if (!empty($search_value)) {
        $sql_search_products .= " AND concat(productName, productDescription) LIKE '%$search_value%'";
    }

    // CATEGORY FILTER (if selected --- if not -- it will be 'all' default)
    if ($selected_category !== 'all') {
        $sql_search_products .= " AND categoryID = '$selected_category'";
    }

    //ONE RESULT VARIABLE (to help choose what to show/filter search+cat)
    $products_result = mysqli_query($conn, $sql_search_products);
    
    /* could do error handling */
    if (!$products_result) {
        die("Error: Main Search Failed: ".mysqli_error($conn));
    }
}
else {
    //(No Search Button Clicked) -- VIEW ALL PRODUCTS in stock
    $sql_all_products = "SELECT * FROM products WHERE productStockQuantity>0";
    $all_products_result = mysqli_query($conn, $sql_all_products);

    //error handling -- if unsuccessful query for all products
    if (!$all_products_result) {
        die("All Product Query Error: ".mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View All Products</title>

    <link rel="stylesheet" href="styleV2.css">

    <style>
        main {padding-top: 100px; } 

        @media screen and (max-width: 768px) {
            main {padding-top: 120px; } 
        }
    </style>

</head>

<body>
    <header>
        <?php /* include 'include/navigation.php'; */ ?>
        <nav class="navigationBar">

            <div class="leftNavigation">
                <!-- Clickable Logo & Text to redirect to Home / Welcome Landing Page -->
                <a href="welcome_landing.php">
                    <!-- Logo -->
                    <div class="logoSpazaShap">
                        <img src="images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                        <!-- keep image source as is !! -->
                        <p>Spaza Shap: Shopping Spaza Style</p>
                    </div>
                </a>

                <!-- Left Navigation Links (Home, Products, About) -->
                <ul class="navigationBarList leftNavLinks">
                    <li><a href="welcome_landing.php">Home</a></li>
                    <li><a href="view_all_products.php">Products</a></li> 
                    <!--Products - buy product (buyers)-->
                    <li><a href="about.php">About</a></li>
                </ul>
            </div>

            <!-- Search Bar -->
            <div class="centerNavigation">
                <!-- <form class="searchForm" action="search_product.php" method="GET"> -->
                <form class="navSearchForm" action="view_all_products.php" method="GET">
                    <input type="search" id="search" name="search" placeholder="Search for product...">
                    <button class="navSearchButton" name="navSearchButton">Search</button>
                </form>
            </div>

            <!-- Right Navigation Links (Register Login) (Cart, Profile)   
            **removed profile for base model-->
            <div class="rightNavigation navigationBarList">
                <ul class="navigationBarList rightNavLinks">
                
                        <!-- Guest User works :)  -->
                        <?php if (!isset($_SESSION['userLoggedIn'])): {  ?>
                            <li><a href="nonUser_index.php" class="navButton">Register</a></li>
                            <li><a href="login.html" class="navButton">Login</a></li>
                        <!-- admin vs buyer vs seller -->
                        
                        <!-- TEST ADMIN!!! -->
                        <?php  }elseif ($_SESSION["userRole"] == "Admin"): { ?>
                            <li><a href="admin/admin_panel.php" class="navButton">Admin Panel </a></li>
                            <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                            <li><a href="logout.php" class="navButton">Logout</a></li>
            
                        <!-- TEST  SELLER!!! -->
                        <?php  }elseif ($_SESSION["userRole"] == "Seller"): { ?>
                            <li><a href="seller/seller_panel.php" class="navButton">Seller Panel </a></li>
                            <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                            <li><a href="logout.php" class="navButton">Logout</a></li>

                        <!-- TEST  BUYER (ELSE)!!! -->
                        <?php  }elseif ($_SESSION["userRole"] == "Buyer"): { ?>
                            <li><a href="buyer_cart.php" class="navButton">Cart</a></li>
                            <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                            <li><a href="logout.php" class="navButton">Logout</a></li>

                    <?php } endif; ?>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <h2>ALL PRODUCTS: View, Search, Filter by Category</h2>

        <form class="mainSearchForm" action="view_all_products.php" method="GET">
            <!--  categoryID -- give predefined categories -->
                <!-- input for the different Product categories -- can be pre-added in DB then sourced to populate here -->
                <!-- Filter Search by Product Categories: -->
                <label for="productCategories" class="productCategoriesLabelMainSearch">FILTER:</label>
                <select name="productCategories" id="productCategories">
                    <option value="all">--All Product Categories--</option>
                    <!-- php to add category id and category name in select option html elements -->
                    <?php while ($categoryRow = mysqli_fetch_assoc($categoryQuery)):  /*while more categories*/ ?>
                        <option value="<?php echo $categoryRow['categoryID']; ?>">
                            <?php echo htmlspecialchars($categoryRow['categoryName']); ?> </option>
                    <?php endwhile; ?>
                </select>

                <!-- search input and button **STYLE STILL-->
                <input type="search" id="mainSearch" name="mainSearch" placeholder="Search for product...">
                      
            <button name="mainSearchButton" id="mainSearchButton" >Search</button>
        </form>


        <div class="productCardContainer">
            <?php
            // Use search results if available, else if category, else use all products
            if (isset($search_products_result)) {
                $result = $search_products_result; //from nav search 
            } elseif (isset($products_result)) {
                $result = $products_result;  // from search with category (main search)
            } elseif (isset($all_products_result)) {
                $result = $all_products_result; //all products (main search)
            }else{
                $result = null;
            }

            if ($result && mysqli_num_rows($result) > 0) {
                while ($productRow = mysqli_fetch_assoc($result)) {
            ?>

                    <!-- =================  PRODUCT CARD ===================   -->
                    <div class="productCard">
                        <h4><?php echo $productRow['productName'] ?></h4>
                        <!-- <img class="productImageSource" alt="product image" 
                    src="images/logoSpazaShap.png" > --><!-- !!HOW!! -->
                        <!-- tester to view image -->
                        <img class="productImageSource" alt="product image"
                            src="product_images/<?php echo htmlspecialchars($productRow['productImageSource']) ?>">
                    

                        <p class="productPrice">R<?php echo $productRow['productPrice'] ?></p>
                        <p class="productDescription"><?php echo $productRow['productDescription'] ?></p>
                        <!-- <p><button class="addProductToCartBtn">Add to Cart</button></p> -->
                        
                        <?php
                            /* User not logged in */
                            if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true){
                        ?>
                            <p><a href="login.html" class="addProductToCartBtn">Add to Cart</a></p>

                        <?php
                            /* user = buyer --- can proceed to cart to order + pay */
                            }else if ($_SESSION["userRole"] == "Buyer"){

                                //added for buyer buying *new
                                $email = $_SESSION["email"]; 
                        ?>
                        <!-- <p><a href="" class="addProductToCartBtn">Add to Cart</a></p> -->
                        <p><a class="addProductToCartBtn"
                        href="add_to_cart.php?productID=<?php echo $productRow['productID']?>&buyerEmail=<?php echo $email ?>">Add to Cart</a>
                        </p> <!-- fixed %20 spaces in url -->
                        
                <?php
                    }else  { 
                        /*if ($_SESSION["userRole"] == "Seller")*/
                        /*if ($_SESSION["userRole"] == "Admin")*/
                ?>

                    <p><a href="" class="addProductToCartBtn">Add to Cart</a></p> 
                    <!-- empty href - stay on same page -->
                <?php
                    }
                ?>
                    </div>
            <?php
                }
            } else {
                echo "<p>No products found.</p>";
            }
            ?>
        </div>
    </main>
    <!-- FOOTER -->
    <?php include 'include/footer.php'; ?>
</body>
</html>