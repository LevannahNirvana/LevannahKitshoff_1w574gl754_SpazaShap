<!-- Levannah Kitshoff -   11 May 2025 
buyer_register.php -->
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    /* echo "Hello again Buyer <br>"; */

    //get variables  & trim, sanitize values
    //email, password, firstName, lastName, phoneNumber, address
    //============GET AND VALIDATE DATA===================
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $firstName = trim($_POST['firstName']);
    $lastName = trim($_POST['lastName']);
    $phoneNumber = trim($_POST['phoneNumber']);
    $address = trim($_POST['address']);
    //further sanitization --> 

    if (empty($email) || empty($password) || empty($firstName) || empty($lastName) || empty($phoneNumber) || empty($address)) {
        die("ERROR: All fields are required");
    }

    //Validate email for all user role types
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("ERROR: Invalid Email Format (SS Validation)");
        //die or echo --- die --stops execution (will not continue but sends err message to user)
    }

    //================DATABASE CONNECTION========================
    //------------- DATABASE CONNECT (INSERT PRODUCT)   *PROCEDURAL
    //#1 DB Connection Variables & #2 DB CONNECT & #3 CHECK DB CONNECT 
    require_once 'include/dbconnect.php';  
    //works - inside same directory is include file - within it is dbconnect

    //#4 CHECK IF EMAIL EXISTS ----------BUYER------------
    $sql_check_buyer_email = "SELECT * FROM buyers WHERE buyerEmail ='$email'";
    $buyer_check = mysqli_query($conn, $sql_check_buyer_email);

    if (mysqli_num_rows($buyer_check) > 0) {
        die("Error: Buyer Email Already Registered on SpazaShap");
    }

    //#5 HASHING THE PASSWORD:  (before insert)
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    //#INSERT BUYER 
    $sql_insert_buyer = "INSERT INTO buyers(buyerEmail, buyerPassword, buyerFirstName, buyerLastName, buyerPhoneNumber, buyerAddress) 
    VALUES ('$email', '$password_hash', '$firstName', '$lastName', '$phoneNumber', '$address')";

    //CHECK INSERT SUCCESS
    if (mysqli_query($conn, $sql_insert_buyer)) {
        // if successful insert -- redirect to login
        header("Location: login.html");
        exit;
    } else {
        //when not successful insert
        echo "Error: ".mysqli_error($conn);
    }
    //#CLOSE DB CONNECTION 
    mysqli_close($conn);
}
?>
