<!-- Levannah Kitshoff 1w574gl75  - June 2025 
    - About page 
-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome User</title>

    <link rel="stylesheet" href="styleV2.css">
    <style>
        /*mobile responsiveness - moves main down below nav */
        main {padding-top: 100px; } 

        @media screen and (max-width: 768px) {
            main {padding-top: 150px; } 
        }
        /* ---------------------------------- */

        /* -----------ABOUT CONTAINER----------------------- */
        .aboutContainer {
            background-color: white; /* same as body colour */
            padding: 25px;
            margin-bottom: 30px;
            border: 1px solid #c3c0c0;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .aboutContainer h1, .aboutContainer h2 {
            color: #080808; //dark / blackish
            margin-bottom: 10px;
        }
        .aboutContainer p{
            font-size: 16px;
            line-height: 1.6;
        }
    </style>
</head>

<body>
    <header>
        <?php /* include 'include/navigation.php'; */ ?>
        <nav class="navigationBar">

            <div class="leftNavigation">
                <!-- Clickable Logo & Text to redirect to Home / Welcome Landing Page -->
                <a href="welcome_landing.php">
                    <!-- Logo -->
                    <div class="logoSpazaShap">
                        <img src="images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                        <!-- keep image source as is !! -->
                        <p>Spaza Shap: Shopping Spaza Style</p>
                    </div>
                </a>

                <!-- Left Navigation Links (Home, Products, About) -->
                <ul class="navigationBarList leftNavLinks">
                    <li><a href="welcome_landing.php">Home</a></li>
                    <li><a href="view_all_products.php">Products</a></li> 
                    <!--Products - buy product (buyers)-->
                    <li><a href="about.php">About</a></li>
                </ul>
            </div>

            <!-- Search Bar -->
            <div class="centerNavigation">
                <form class="navSearchForm" action="view_all_products.php" method="GET">
                    <input type="search" id="search" name="search" placeholder="Search for product...">
                    <button class="navSearchButton" name="navSearchButton">Search</button>
                </form>
            </div>

            <!-- Right Navigation Links (Register Login) (Cart, Profile)   
            **removed profile for base model-->
            <div class="rightNavigation navigationBarList">
                <ul class="navigationBarList rightNavLinks">
            
                        <!-- Guest User  -->
                        <?php if (!isset($_SESSION['userLoggedIn'])): {  ?>
                            <li><a href="nonUser_index.php" class="navButton">Register</a></li>
                            <li><a href="login.html" class="navButton">Login</a></li>
                        <!-- admin vs buyer vs seller -->
                        
                        <!-- ADMIN -->
                        <?php  }elseif ($_SESSION["userRole"] == "Admin"): { ?>
                            <li><a href="admin/admin_panel.php" class="navButton">Admin Panel </a></li>
                            <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                            <li><a href="logout.php" class="navButton">Logout</a></li>
            
                        <!-- SELLER-->
                        <?php  }elseif ($_SESSION["userRole"] == "Seller"): { ?>
                            <li><a href="seller/seller_panel.php" class="navButton">Seller Panel </a></li>
                            <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                            <li><a href="logout.php" class="navButton">Logout</a></li>

                        <!-- BUYER (ELSE)-->
                        <?php  }elseif ($_SESSION["userRole"] == "Buyer"): { ?>
                            <li><a href="buyer_cart.php" class="navButton">Cart</a></li>
                            <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                            <li><a href="logout.php" class="navButton">Logout</a></li>

                    <?php } endif; ?>
                </ul>
            </div>
        </nav>
    </header>
    
    <main>
        <div class="aboutContainer ">
            <h1>Welcome to SpazaShap</h1>
            <p>SpazaShap is South Africa’s community-driven C2C e-commerce platform </p>
            <p>Empowering informal traders and buyers to connect and trade online - Spaza Shap Style</p>
        </div>
        <div class="aboutContainer">
            <h2>Built for the Community</h2>
            <p>Strengthening South Africa’s informal economy — one spaza shop at a time.</p>
            <p>Thank you for joining our journey!</p>
        </div>
    </main>
    <!-- FOOTER -->
    <?php include 'include/footer.php'; ?>

    <script></script>
</body>
</html>