<!-- Levannah Kitshoff - June 2025 
        buyer_orders.php
-->
<?php
//--------------- SESSIONS --------------
session_start();
//----------------------------------------------------

//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: login.html"); /* possibly header("Location: ../login.html"); */
    exit();
}
//if not a SELLER **CHECK ROLE   (should only allow seller access here)
if ($_SESSION["userRole"] != "Buyer") {
    header("Location: welcome_landing.php");   /* possibly header("Location:../ welcome_landing.php"); */
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Buyers";
}
?>

<?php
//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once 'include/dbconnect.php';  

$buyerEmail = $_SESSION['email']; 
// Get buyerID using session email
$sql_buyer = "SELECT buyerID FROM buyers WHERE buyerEmail = '$buyerEmail'";
$result_buyer = mysqli_query($conn, $sql_buyer);
$buyerRow = mysqli_fetch_assoc($result_buyer);
$buyerID = $buyerRow['buyerID'];

//-------ORDER DETAILS
//orders(orderID, orderDate, orderTotal, orderStatus, buyerID)   *FK buyerID

//-------ORDER_PRODUCTS DETAILS
//order_products(orderID, productID, quantity, price_at_order_time)   
//*orderID FK , productID FK    *COMPOSITE PK (orderID, productID)


//VIEW ALL ORDERS -- for specific buyerID
$sql_buyer_orders= "SELECT * FROM orders WHERE buyerID ='$buyerID'";
$buyer_orders_result = mysqli_query($conn, $sql_buyer_orders);

//error handling -- if unsuccessful query for buyer orders
if (!$buyer_orders_result) {
    die("Buyer Orders Query Error: ".mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buyer Orders</title>
    <link rel="stylesheet" href="styleV2.css">

    <style>
        /* mobile responsivenes to move main below nav that enlarged */
        main {padding-top: 100px; } 

        @media screen and (max-width: 768px) {
            main {padding-top: 120px; } 
        }

        /* list style -- none to remove bullet point */
        li>a{
            list-style-type:none;
        }

        /* buyer order table styling */
        .buyer_table_orders {
                border: 3px solid black;
                margin-top: 35px;
            }

            th {
                background: #2f84d9;
                font-weight: bold;
                text-align: center;
                padding: 9px;
            }

            td {
                text-align: center;
                padding: 5px;
            }
    </style>
</head>

<body>
<header>
        <?php /* include 'include/navigation.php'; */ ?>
        <nav class="navigationBar">

    <div class="leftNavigation">
        <!-- Clickable Logo & Text to redirect to Home / Welcome Landing Page -->
        <a href="welcome_landing.php">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>
        </a>

        <!-- Left Navigation Links (Home, Products, About) -->
        <ul class="navigationBarList leftNavLinks">
            <li><a href="welcome_landing.php">Home</a></li>
            <li><a href="view_all_products.php">Products</a></li> <!--Products - buy product (buyers)-->
            <li><a href="about.html">About</a></li>
        </ul>
    </div>

    <!-- Search Bar -->
    <div class="centerNavigation">
        <!-- <form class="searchForm" action="search_product.php" method="GET"> -->
        <form class="navSearchForm" action="view_all_products.php" method="GET">
            <input type="search" id="search" name="search" placeholder="Search for product...">
            <button class="navSearchButton" name="navSearchButton">Search</button>
        </form>
    </div>

    <!-- Right Navigation Links (Register Login) (Cart, Profile)   **removed profile for base model-->
    <div class="rightNavigation navigationBarList">
        <ul class="navigationBarList rightNavLinks">
                <!-- ADMIN -->
                <?php  if ($_SESSION["userRole"] == "Admin"): { ?>
                    <li><a href="admin/admin_panel.php" class="navButton">Admin Panel </a></li>
                    <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                    <li><a href="logout.php" class="navButton">Logout</a></li>
      
                <!--  SELLER -->
                <?php  }elseif ($_SESSION["userRole"] == "Seller"): { ?>
                    <li><a href="seller/seller_panel.php" class="navButton">Seller Panel </a></li>
                    <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                    <li><a href="logout.php" class="navButton">Logout</a></li>

                <!-- BUYER (ELSE) -->
                <?php  }elseif ($_SESSION["userRole"] == "Buyer"): { ?>
                    <li><a href="buyer_cart.php" class="navButton">Cart</a></li>
                    <!-- <li><a href="user_profile.php" class="navButton">Profile</a></li> -->
                    <li><a href="logout.php" class="navButton">Logout</a></li>

            <?php } endif; ?>
        </ul>
    </div>
</nav>
    </header>

    <main>
    <br><br>
        <h2>Buyer Orders: </h2> 
        <h3>Collect at: Address: 4 Lava Lane, Durbanville, Cape Town 7550 
        <br> within 3-5 working days from orderDate</h3>

        <div>
        <table class="buyer_table_orders">
                        <!-- Table Row -- for headers -->
                        <tr>
                            <th>OrderID</th>
                            <th>Order Date</th>
                            <th>Order Total</th>
                            <th>Order Status </th>
                        </tr>
            <?php
            if ($buyer_orders_result && mysqli_num_rows($buyer_orders_result) > 0) {
                while ($orderRow = mysqli_fetch_assoc($buyer_orders_result)) {
            ?>
                    <!-- Table row for Data (4 headers thus 4 data) -->
                <tr>
                    <!--orderID-->
                    <td><?php echo $orderRow['orderID'] ?></td>
                    <!--orderDate-->
                    <td><?php echo $orderRow['orderDate'] ?></td>
                    <!--orderTotal-->
                    <td><?php echo $orderRow['orderTotal'] ?></td>
                    <!--orderStatus-->
                    <td><?php echo $orderRow['orderStatus'] ?></td>
                </tr>
                   
            <?php }
            } else {
                echo "<p>No Orders found.</p>";
            }
            ?>
        </table>
        <br><br>  
        </div>
    </main>

    <!-- FOOTER php-->
    <footer>
    <?php include 'include/footer.php'; ?>
    </footer>
    <script></script>
</body>
</html>
