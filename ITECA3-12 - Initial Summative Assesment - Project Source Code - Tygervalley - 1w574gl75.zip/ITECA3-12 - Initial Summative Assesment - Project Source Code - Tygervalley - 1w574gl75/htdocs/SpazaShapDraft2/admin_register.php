<?php
//Levannah Kitshoff -  11 May 2025
//admin_register.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //get variables  & trim, sanitize values
    //email, password, firstName, lastName, ... **check --> adminPassCode
    //============GET AND VALIDATE DATA===================
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $firstName = trim($_POST['firstName']);
    $lastName = trim($_POST['lastName']);
    //admin -- special passcode
    $adminPassCode = trim($_POST['adminPassCode']);
    //further sanitization --> 

    if (empty($email) || empty($password) || 
    empty($firstName) || empty($lastName) || empty($adminPassCode)) {
        die("ERROR: All fields are required");
    }

    //Validate email for all user role types
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("ERROR: Invalid Email Format (SS Validation)");
        //die or echo --- die --stops execution (will not continue but sends err message to user)
    }

    //Validate **check --> adminPassCode 

    //-----------------AFTER VALIDATION ----------------- 
    //================DATABASE CONNECTION========================
    //------------- DATABASE CONNECT (INSERT PRODUCT)   *PROCEDURAL
    //#1 DB Connection Variables & #2 DB CONNECT & #3 CHECK DB CONNECT 
    require_once 'include/dbconnect.php';  
    //works - inside same directory is include file - within it is dbconnect

    //#4 CHECK IF EMAIL EXISTS ----------ADMIN------------
    $sql_check_admin_email = "SELECT * FROM admins WHERE adminEmail ='$email'";
    $admin_check = mysqli_query($conn, $sql_check_admin_email);

    if (mysqli_num_rows($admin_check) > 0) {
        die("Error: Admin Email Already Registered on SpazaShap");
    }

    //-- ADDED:    SPECIAL ADMIN CODE CONDITION BEFORE CONTINUING... -----
    $ADMIN_CODE = "admin123"; //!!!! NB TO CHANGE * IDEA FOR AUTO GENERATING RANDOM PERIODICALLY
    if ($adminPassCode != $ADMIN_CODE) {
        die("Error: Incorrect Admin PassCode");
    }
    //--------------------------------------------------------------
    //----------------------------else continue----------------------
    //HASHING THE PASSWORD:  (before inserts)
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    //#INSERT ADMIN 
    $sql_insert_admin = 
    "INSERT INTO admins(adminEmail, adminPassword, adminFirstName, adminLastName) VALUES ('$email', '$password_hash', '$firstName', '$lastName')";

    //CHECK INSERT SUCCESS
    if (mysqli_query($conn, $sql_insert_admin)) {
        // if successful insert -- redirect to login
        header("Location: login.html");
        exit;
    } else {
        //when not successful insert
        echo "Error: " . mysqli_error($conn);
    }
    //CLOSE DB CONNECTION 
    mysqli_close($conn);
}
?>