<!-- Levannah Kitshoff - June 2025 
        buyer_cart.php
-->
<?php
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: login.html"); /* possibly header("Location: ../login.html"); */
    exit();
}

//if not a SELLER **CHECK ROLE   (should only allow seller access here)
if ($_SESSION["userRole"] != "Buyer") {
    header("Location: welcome_landing.php");   /* possibly header("Location:../ welcome_landing.php"); */
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Buyers";
}
?>

<?php
//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once 'include/dbconnect.php';

//GET values passed  (productID from displayed product and email from sessions)
$productID = $_GET['productID'];

$buyerEmail = $_SESSION['email']; 
// Get buyerID using session email
$sql_buyer = "SELECT buyerID FROM buyers WHERE buyerEmail = '$buyerEmail'";
$result_buyer = mysqli_query($conn, $sql_buyer);
$buyerRow = mysqli_fetch_assoc($result_buyer);
$buyerID = $buyerRow['buyerID'];

//-------ORDER DETAILS
//orders(orderID, orderDate, orderTotal, orderStatus, buyerID)   *FK buyerID

//-------ORDER_PRODUCTS DETAILS
//order_products(orderID, productID, quantity, price_at_order_time)   
//*orderID FK , productID FK    *COMPOSITE PK (orderID, productID)
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Buyer Cart</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleV2.css">
    <style>
    /*cart styling*/
        .cart_order_products {
            background-color: #f9f9f9;
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-top: 20px;
        }

    /*cart order products styling */
        .cart_order_product {
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 10px;
            background-color: #f9f9f9;
        }

        .cart_order_product img {
            margin-right: 15px;
            border-radius: 8px;
        }

        /*Mobile Responsiveness - moves main down to see below the nav */
        main {padding-top: 120px; } 

        @media screen and (max-width: 768px) {
            main {padding-top: 140px; } 
        }

        /*button styling  -- id = checkoutButton */
        /*similar to nav search*/ 
        form>#checkoutButton{  
            background:  #3d3e3d; 
            color: white;
            border: solid #c3c0c0; 
            border-radius: 50px;
            cursor: pointer;
            
            /* width: 100%; */
            padding: 10px;
            margin: 1rem 1rem; 
        }
        form>#checkoutButton:hover {
            opacity: 0.6;
        }

        /*SHIPPING FIELDSET STYLE */
        #shippingFieldset{
            margin: 1rem 0; 
            padding: 1rem; 
            border: 1px 
            solid #ccc; 
            border-radius: 8px;
        }
    </style>
</head>

<body>
<header>
    <nav class="navigationBar">

        <div class="leftNavigation">
            <!-- Clickable Logo & Text to redirect to Home / Welcome Landing Page -->
            <a href="welcome_landing.php">
                <!-- Logo -->
                <div class="logoSpazaShap">
                    <img src="images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                    <p>Spaza Shap: Shopping Spaza Style</p>
                </div>
            </a>

            <!-- Left Navigation Links (Home, Products, About) -->
            <ul class="navigationBarList leftNavLinks">
                <li><a href="welcome_landing.php">Home</a></li>
                <li><a href="view_all_products.php">Products</a></li> 
                <!--Products - buy product (buyers)-->
                <li><a href="about.html">About</a></li>
            </ul>
        </div>

        <!-- Search Bar -->
        <div class="centerNavigation">
            <form class="navSearchForm" action="view_all_products.php" method="GET">
                <input type="search" id="search" name="search" placeholder="Search for product...">
                <button class="navSearchButton" name="navSearchButton">Search</button>
            </form>
        </div>

        <!-- Right Navigation Links (Register Login) (**ORDERS, Profile)   **removed profile for base model-->
        <div class="rightNavigation navigationBarList">
            <ul class="navigationBarList rightNavLinks">
                        <li><a href="buyer_orders.php" class="navButton">Orders</a></li>
                        <li><a href="logout.php" class="navButton">Logout</a></li>
            </ul>
        </div>
    </nav>
    </header> 

    <main>
        <h2>Buyer Cart</h2>
        <?php
        //---------------- CHECK if CART/ORDER EXISTS for BUYER
        $sql_order_cart = "SELECT orderID FROM orders WHERE buyerID = '$buyerID' AND orderStatus = 'Cart'";
        $result_order_cart = mysqli_query($conn, $sql_order_cart);

        //--if there is order/cart for buyer
        if (mysqli_num_rows($result_order_cart) > 0) {
            $cart = mysqli_fetch_assoc($result_order_cart);
            $orderID = $cart['orderID'];
        ?>

            <p><strong>Cart ID:</strong><?php echo $orderID;?></p>
            <div class='cart_order_products'>
            
        <?php
            //-------ORDER DETAILS
            //orders(orderID, orderDate, orderTotal, orderStatus, buyerID)   *FK buyerID

            //-------ORDER_PRODUCTS DETAILS
            //order_products(orderID, productID, quantity, price_at_order_time)   
            //*orderID FK , productID FK    *COMPOSITE PK (orderID, productID)
                        // Fetch products in the cart
            $sql_order_products = 
            "SELECT order_products.productID, order_products.quantity, order_products.price_at_order_time,
                                    products.productName, products.productImageSource
                             FROM order_products
                             LEFT JOIN products ON order_products.productID = products.productID
                             WHERE order_products.orderID = '$orderID'";
            $result_order_products = mysqli_query($conn, $sql_order_products);
            //left join instead for orphaned rows

            //if results (there are rows for order_products)
            if (mysqli_num_rows($result_order_products) > 0) {
                $final__products_total = 0;

        ?>

            <?php
                //Loop through order_products within cart  (to display)
                while ($order_productRow = mysqli_fetch_assoc($result_order_products)) {
                    // skip orphaned product rows
                    if (!$order_productRow['productName']) {
                        continue; 
                    }
                    //GET ORDER PRODUCT INFO and SHOW SUBTOTALS 
                    $productName = $order_productRow['productName'];
                    $quantity = $order_productRow['quantity'];
                    $price_at_order_time = $order_productRow['price_at_order_time'];
                    $image = $order_productRow['productImageSource'];
                    $subtotal = $quantity * $price_at_order_time;
                    $final_products_total += $subtotal;
            ?>
                    <!-- Display EACH OF THE CART ORDER PRODUCTS --> 
                    <div class="cart_order_product">
                        <img src="product_images/<?php echo $image; ?>" 
                        width="100" alt="<?php echo $productName; ?>">

                        <p><strong><?php echo $productName; ?></strong></p>
                        <p>Quantity: <?php echo $quantity; ?></p>
                        <p>Price: R <?php echo number_format($price_at_order_time, 2); ?></p>
                        <p>Product Subtotal: R <?php echo number_format($subtotal, 2); ?></p>
                        <hr>
                    </div>
            <?php
                }
                //When all order_product rows displayed -- show final total (before shipping ) 
            ?>
                <p><strong>
                    Total (Before Shipping): R <?php echo number_format($final_products_total, 2); ?> 
                </strong></p>

                <!-- FORM TO SUBMIT -- CHECKOUT CART --->
                <form method='POST' action='buyer_checkout.php'>
                    <!-- hidden values - orderID and total *for base total before shippingchoice --> 
                    <input type='hidden' name='orderID' value=<?php echo $orderID?> >
                    <input type='hidden' id='baseTotal' value="<?php echo $final_products_total; ?>">

                    <!-- fieldset added for shipping options to choose - then update final total --> 
                    <fieldset id="shippingFieldset">
                    <legend><strong>Select Delivery & Payment Option</strong></legend>

                    <label>
                    <input type="radio" name="deliveryOption" value="pickup" 
                        required onclick="updateTotal('pickup')">
                        In-Store Pickup (Pay In-Store) - R0
                    </label><br>

                    <label>
                    <input type="radio" name="deliveryOption" value="delivery" 
                        onclick="updateTotal('delivery')">
                        Standard Delivery (Pay Online) - R100 or Free if Total > R1000
                    </label><br>
                    </fieldset>

                    <!-- FINAL TOTAL incl SHIPPING --> 
                    <p id="finalTotalDisplay"><strong>
                    Final Total (Incl. Shipping): R <?php echo number_format($final_products_total, 2);?>
                    </strong></p>

                    <!-- CHECKOUT BUTTON -->
                    <input id="checkoutButton" type='submit' name='checkout' value='Proceed to Checkout' >
                </form>

            </div>

            <?php
            } else {
            ?>
                <!-- NO ORDER PRODUCTS within CART/ORDER-->
                <p>Your cart is empty.</p>

            <?php
            }
        } else { ?>
            <!-- if there is NO order/cart for buyer -->
            <p>No current buyer cart found.</p>
        <?php
        }
        ?>
    </main>
    <!-- FOOTER -->
    <?php include 'include/footer.php'; ?>

    <script>
    //FUNCTION TO CALCULATE UPDATED TOTAL 
    function updateTotal(shipping_option) {
        //get baseTotal and then add shipping fee *if any for final total
        const baseTotal = parseFloat(document.getElementById('baseTotal').value);
        let finalTotal = baseTotal;

        if (shipping_option === 'pickup') {
            // No shipping fee
        } else if (shipping_option === 'delivery') {
            if (baseTotal < 1000) {
                finalTotal += 100;
            } // else free shipping
        }
        //update finalTotalDisplay element inner HTML value to show new updated total *dynamically
        document.getElementById('finalTotalDisplay').innerHTML =
            `<strong>Final Total (Incl. Shipping): R ${finalTotal.toFixed(2)}</strong>`;
    }
    </script>

</body>
</html>