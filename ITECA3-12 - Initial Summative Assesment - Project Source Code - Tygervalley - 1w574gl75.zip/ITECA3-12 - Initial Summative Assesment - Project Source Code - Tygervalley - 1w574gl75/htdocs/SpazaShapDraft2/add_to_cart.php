<!-- Levannah Kitshoff - June 2025 
        add_to_cart.php
-->
<?php
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: login.html"); /* possibly header("Location: ../login.html"); */
    exit();
}
//if not a BUYER **CHECK ROLE   (should only allow buyer access here)
if ($_SESSION["userRole"] != "Buyer") {
    header("Location: welcome_landing.php");
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Buyers";
}
?>

<?php
//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once 'include/dbconnect.php';  

//---------------- GET buyerID (by using BuyerEmail) ----------------
$buyerEmail = $_SESSION['email']; //buyerEmail from session

$sql_buyer = "SELECT buyerID FROM buyers WHERE buyerEmail = '$buyerEmail'";
$result_buyer = mysqli_query($conn, $sql_buyer);
$buyer = mysqli_fetch_assoc($result_buyer);
$buyerID = $buyer['buyerID']; //buyerID retrieved


//---------------- GET productID from GET ----------------
if (!isset($_GET['productID'])) {
    die("Error: ProductID Required (Missing)");
}
$productID = intval($_GET['productID']); //intval--returns integer of variable

//---------------- GET PRODUCT DETAILS (DB) ----------------
$sql_product = "SELECT * FROM products WHERE productID = '$productID'";
$result_product = mysqli_query($conn, $sql_product);

//-- if no product matching productID
if (mysqli_num_rows($result_product) === 0) {
    die("Product not found.");
}
$product = mysqli_fetch_assoc($result_product);
$productPrice = $product['productPrice'];  //productPrice
$productStockQuantity = $product['productStockQuantity']; //productStockQuantity

//---------------- CHECK if CART/ORDER EXISTS for BUYER  --FIND OR CREATE cart
$sql_buyer_cart = "SELECT orderID FROM orders WHERE buyerID = '$buyerID' AND orderStatus = 'Cart'";
$result_buyer_cart = mysqli_query($conn, $sql_buyer_cart);

//if there is order/cart for buyer (find order/cart) 
if (mysqli_num_rows($result_buyer_cart) > 0) {
    $buyer_cart_row = mysqli_fetch_assoc($result_buyer_cart);
    $orderID = $buyer_cart_row['orderID'];
} else {
    // No cart/order exists, create cart/order (no orderDate yet until checkout)
    $sql_create_buyer_cart = "INSERT INTO orders (buyerID, orderStatus) VALUES ('$buyerID', 'Cart')";
    mysqli_query($conn, $sql_create_buyer_cart);
    $orderID = mysqli_insert_id($conn); // get new orderID
}

//---------------- CHECK PRODUCT ALREADY ADDED INTO CART
//if so... update quantity (+1)  
    //*check that order_products(quantity) does not exceed current products(productStockQuantity) 
//otherwise add order_product and quantity 1    
$sql_check_quantity = "SELECT quantity FROM order_products WHERE orderID = '$orderID' AND productID = '$productID'";
$result_check_quantity = mysqli_query($conn, $sql_check_quantity);

//if results (there are rows for the product quantity returned)
if (mysqli_num_rows($result_check_quantity) > 0) {
    $productQuantityRow = mysqli_fetch_assoc($result_check_quantity);
    $currentQuantity = $productQuantityRow['quantity'];
    $newQuantity = $currentQuantity + 1;

    //if trying to add too high quantity of product
    if ($newQuantity > $productStockQuantity) {
        $_SESSION['cart_message'] = "Max stock quantity for product";
    } else {
        $sql_update = "UPDATE order_products 
                       SET quantity = '$newQuantity' 
                       WHERE orderID = '$orderID' AND productID = '$productID'";
        if (!$result = mysqli_query($conn, $sql_update)) {
            die("Update cart product failed: ".mysqli_error($conn));
        }
        $_SESSION['cart_message'] = "Quantity updated to $newQuantity.";
    }
} //product has not been added cart before - add to cart (insert into order_products)
    else {
    if ($productStockQuantity > 0) {
        $sql_insert_order_product = "INSERT INTO order_products 
                       (orderID, productID, quantity, price_at_order_time) 
                       VALUES ('$orderID', '$productID', 1, '$productPrice')";
        if (!$result = mysqli_query($conn, $sql_insert_order_product)) {
            die("Insert cart product failed: ".mysqli_error($conn));
        }
        $_SESSION['cart_message'] = "Product: Added to Cart Successfully";
    } else {
        $_SESSION['cart_message'] = "Product: Out of Stock Error";
    }
}

//------- Redirect to buyer cart once product add to cart process completed -----------
header("Location: buyer_cart.php");
exit();

//show session cart_message on buyer_cart.php 
if (isset($_SESSION['cart_message'])) {
    echo "<p class='message'>" . $_SESSION['cart_message'] . "</p>";
    unset($_SESSION['cart_message']);
}
?>