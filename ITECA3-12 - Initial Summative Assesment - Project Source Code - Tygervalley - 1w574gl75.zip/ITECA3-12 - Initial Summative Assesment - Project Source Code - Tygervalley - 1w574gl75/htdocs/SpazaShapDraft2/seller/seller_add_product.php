<?php
//Levannah Kitshoff - May 2025
//seller_add_product.php

//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html"); //or login.html
    exit();
}
//if not a SELLER **CHECK ROLE   (should only allow seller access here)
if ($_SESSION["userRole"] != "Seller") {
    header("Location: ../welcome_landing.php"); //or seller/seller_panel 
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Sellers";
}

//---------DB CONNECTION---------------
require_once '../include/dbconnect.php';

//UPON LOAD  -- show categories in select option  -- Setup for categoryQuery 
$categoryQuery = mysqli_query($conn, "SELECT categoryID, categoryName FROM product_categories");
//---------------------------------------

//===================IF FORM SUBMITTED VIA POST:  (ADD PRODUCT BUTTON CLICKED)=======================
/* (isset($_POST['addProductSubmitBtn']))  */
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    //============GET AND VALIDATE DATA===================
    $productName = trim($_POST['productName']);
    $productDescription = trim($_POST['productDescription']);
    $productPrice = trim($_POST['productPrice']);
    $productImageSource = trim($_POST['productImageSource']); // image handling occurs at a later stage
    $productStockQuantity = trim($_POST['productStockQuantity']);
    $categoryID = trim($_POST['productCategories']); // gets categoryID from db loaded select option value
    $sellerID = (int)$_SESSION["sellerID"]; //sellerID from the stored SESSION Variable  **STRING TO INT

    //SETUP FOR IMAGE FILE SOURCE (for productImageSource -- input field)
    $productImageFileName = $_FILES['productImageSource']['name'];
    $productImageTempFileName = $_FILES['productImageSource']['tmp_name'];
    $folder = '../product_images/'.$productImageFileName;

    //======= CHECK IF FIELDS ARE EMPTY ==========
    //!! allow for productDescription, productImageSource -- to be null
    if (empty($productName) || empty($productPrice) ||empty($productStockQuantity) || empty($categoryID) ) {
        echo "Error: Fill in All Required Fields";
        exit;
    }

// SQL Insert Product  (prepared statements)
$sql_insert_product_placeholder = 
"INSERT INTO products(productName, productDescription, productPrice, productImageSource , productStockQuantity, sellerID, categoryID) 
VALUES (?, ?, ?, ?, ?, ?, ?)"; /* productStatus */

$sql_insert_product_statement = mysqli_prepare($conn, $sql_insert_product_placeholder); //prep statement
if (!$sql_insert_product_statement) {
    die("Insert failed: " . mysqli_error($conn)); //prepare statement fail
}
mysqli_stmt_bind_param($sql_insert_product_statement, "ssdsiii", /* with status -- ssdsisii */
    $productName,
    $productDescription,
    $productPrice,
    $productImageFileName,
    $productStockQuantity,
    
    $sellerID,
    $categoryID
); /* $productStatus, */ //insert product

// Move image into folder   -- into $folder --- '../product_images/'.$productImageFileName;
if (move_uploaded_file($productImageTempFileName, $folder)) {
    echo "<h2>Image File Uploaded Successfully</h2>";
} else {
    echo "<h2>Error: Image Not Uploaded</h2>";
}

// Execute statement
if (mysqli_stmt_execute($sql_insert_product_statement)) {
    header("Location: ../seller/seller_view_products.php");
    exit;
} else {
    echo "Error : Failed to Add Product: " . mysqli_stmt_error($sql_insert_product_statement);
}

// Close statement
mysqli_stmt_close($sql_insert_product_statement);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Add Product</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css">
    <link rel="stylesheet" href="seller_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->

    <style>
        .sellerContentRight {
            border: solid 1pt black;            
            width: 80%; /*  added to fill more of content */
            margin-top: 10px;
            padding: 10px; /* padding-left: 2px; */
        }

        /* ---------------------------------------------------------- */
        .sellerFormAddProduct {
            justify-content: center;
        }

        .form_area_div { padding: 8px; }

        .form_area_div>label {
            width: 150px;
            display: inline-block;
        }

        .form_area_div>input[type='text'],
        [type='number'] {
            padding: 10px;
            width: 30%;/* same weidth as others (inputs) */
            resize: vertical;/* only adjust height of element */
            box-sizing: border-box;
        }

        .form_area_div>textarea {
            height: 80px; /* larger starting height */
            width: 30%; /* same weidth as others (inputs) */
        }

        /* ================================ */
        /* ---ADD PRODUCT BUTTON--- */
        .form_area_div>#addProductSubmitBtn {
            background-color: blue;
            width: 150px;
        }
        .form_area_div>#addProductSubmitBtn:hover { background-color: dodgerblue; }
 
        /* ---CANCEL ADD PRODUCT BUTTON--- */
        .form_area_div>a>#addProductCancelBtn {
            background-color: red;
            width: 150px;
        }
        .form_area_div>a>#addProductCancelBtn:hover { background-color: darkred; }
        /* ================================ */
    </style>

</head>

<body>
<header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo">
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
</header>

    <main class="mainPanel">
        <div class="sellerPanelContainer">
            <!-- Seller panel sidebar (left shows functionality within ul>li) -->
            <div class="sellerPanelSidebar">

                <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
                <li><a href="../welcome_landing.php">
                        <!-- Logo -->
                        <div class="logoSpazaShapPanel">
                            <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                            style="align-content:center;"> 
                        </div>
                    </a>
                </li>

                <h2>SpazaShap Seller</h2>
                <ul>
                    <li>
                        <a href="seller_panel.php">Seller Panel</a>
                    </li>
                    <li>
                        <a href="seller_add_product.php">Add Product</a>
                    </li>
                    <li>
                        <a href="seller_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="seller_view_orders.php">Orders</a>
                    </li>
                </ul>
            </div>


            <div class="sellerContentRight">
                <h2> Seller Add Product</h2>
                <form class="sellerFormAddProduct"
                    action="" method="POST"
                    enctype="multipart/form-data" 
                    onsubmit="return validateAddProductForm()" ><!--  JAVASCRIPT validation works -->
                    <!-- action="seller_add_product.php" -->

                    <!--productName-->
                    <div class="form_area_div">
                        <label for="productName">Product Name:</label>
                        <input type="text" name="productName" id="productName" 
                        placeholder="e.g. Jean Jacket"
                            value="">
                        <span id="productNameError" class="error"></span>
                    </div>
                    <!--productDescription-->
                    <div class="form_area_div">
                        <label for="productDescription">Product Description:</label>
                        <textarea name="productDescription" id="productDescription"
                            placeholder="e.g. Jean Jacket perfect for outdoors. Made From Denim..."
                            maxlength=400></textarea>
                        <span id="productDescriptionError" class="error"></span>
                    </div>

                    <!-- productPrice -->
                    <div class="form_area_div">
                        <label for="productPrice">Product Price: (R)</label>
                        <input type="number" step="0.01" min="0" 
                        oninput="this.value = Math.abs(this.value)" name="productPrice"
                            id="productPrice" placeholder="9.99">
                        <span id="productPriceError" class="error"></span>
                    </div>

                    <!-- productImageSource -->
                    <div class="form_area_div">
                        <label for="productImageSource">Product Image Source:</label>
                        <input type="file" name="productImageSource" id="productImageSource"
                            accept="image/png, image/gif, image/jpeg"> <!--or accept="image/*"-->
                        <span id="productImageSourceError" class="error"></span>
                    </div>

                    <!-- productStockQuantity-->
                    <div class="form_area_div">
                        <label for="productStockQuantity">Product Stock Quantity:</label>
                        <input type="number" min="0" 
                        oninput="this.value = Math.abs(this.value)" name="productStockQuantity"
                            id="productStockQuantity" placeholder="20"
                            value="<?php echo $productRow['productStockQuantity'] ?>">
                        <span id="productStockQuantityError" class="error"></span>
                    </div>

                    <!--  -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
                    <!-- categoryID -- give predefined categories -->
                    <div class="form_area_div">
                    <!-- input for the different Product categories 
                    -- can be pre-added in DB then sourced to populate here -->

                        <label for="productCategories"> Product Categories:</label>
                        <select name="productCategories" id="productCategories">
                        <!-- <option value="">--Choose a Product Category--</option> -->
                        <!-- php to add category id and category name in select option html elements -->
                        <?php while ($categoryRow = mysqli_fetch_assoc($categoryQuery)):  
                        /*while more categories*/ ?>

                            <option
                                value="<?php echo $categoryRow['categoryID']; ?>">                                  
                                <?php echo htmlspecialchars($categoryRow['categoryName']); ?>
                            </option>

                        <?php endwhile; ?>
                        </select>
                        <span id="productCategoryError" class="error"></span>
                    </div>
                    <!--  -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
                    <!--buttons submit & cancel-->
                    <div class="form_area_div">
                        <button id="addProductSubmitBtn" type="submit" name="addProductSubmitBtn" value="Add product"><b>Add Product</b></button>
                        <a href="seller_view_products.php">
                            <button id="addProductCancelBtn" type="button" name="addProductCancelBtn">
                                <b>Cancel</b>
                            </button>
                        </a>
                    </div>
                </form>
            </div>

        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>

    <!-- JavaScript script for login page -- validation -->
    <script src="add_product_script.js"></script>
</body>
</html>