//Levannah Kitshoff - 11 May 2025  -- add_product_script.js
function validateAddProductForm() {
    //------------------- 1. get input values ------------------------
    let productName = document.getElementById("productName").value.trim();
    let productDescription = document.getElementById("productDescription").value.trim();
    let productPrice = document.getElementById("productPrice").value.trim();
    let productImageSource = document.getElementById("productImageSource").value.trim();
    let productStockQuantity = document.getElementById("productStockQuantity").value.trim();
    //Category  (connected to PRODUCT CATEGORY)
    let productCategory = document.getElementById("productCategories").value.trim();

    //---------------- 2. get error message elements (spans) -----------------
    let productNameError = document.getElementById("productNameError");
    let productDescriptionError = document.getElementById("productDescriptionError");
    let productPriceError = document.getElementById("productPriceError");
    let productImageSourceError = document.getElementById("productImageSourceError");
    let productStockQuantityError = document.getElementById("productStockQuantityError");
    //Category  (connected to PRODUCT CATEGORY)
    let productCategoryError = document.getElementById("productCategoryError");

    //------3. clear previous errors ------
    productNameError.innerHTML = "";
    productDescriptionError.innerHTML = "";
    productPriceError.innerHTML = "";
    productImageSourceError.innerHTML = "";
    productStockQuantityError.innerHTML = "";
    productCategoryError.innerHTML = "";

    //4. -------------------- Validation-------------------
    let isValid = true; //have to return a true or false  -- therefore have isValid
    //productName 
    if (productName === "") {
        productNameError.innerHTML = "Product Name is Required";
        isValid = false; //false  -- prevent to submit
    }
    //productDescription
    if (productDescription === "") {
        productDescriptionError.innerHTML = "Product Description is Required";
        isValid = false; //false  -- prevent to submit
    }
    // productPrice, 
    if (productPrice === "") {
        productPriceError.innerHTML = "Product Price is Required";
        isValid = false; //false  -- prevent to submit
    }//**FORMAT CHECK **
    //if below 0, or not a number  -- prevented negative inputs on input properties  
     
    //** productImageSource
    if (productImageSource === "") {
        productImageSourceError.innerHTML = "Product Image is Required";
        isValid = false; //false  -- prevent to submit
    }
    //productQuantity
    if (productStockQuantity === "") {
        productStockQuantityError.innerHTML = "Product Quantity is Required";
        isValid = false; //false  -- prevent to submit
    }
    //productCategory
    if (productCategory === "") {
        productCategoryError.innerHTML = "Product Category is Required";
        isValid = false; //false  -- prevent to submit
    }
    return isValid;
}