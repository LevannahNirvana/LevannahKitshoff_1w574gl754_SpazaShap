<?php
//Levannah Kitshoff - May 2025 - seller_panel.php 
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html");
    exit();
}
//if not a SELLER **CHECK ROLE   (should only allow seller access here)
if ($_SESSION["userRole"] != "Seller") {
    header("Location: ../welcome_landing.php"); 
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Sellers";
}
?>

<?php 
//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once '../include/dbconnect.php'; 

//---PRODUCTS -- "SELECT COUNT(*) FROM products WHERE sellerID = '$sellerID' ;";  or "SELECT * FROM products sellerID = '$sellerID'" 
/* seller specific count */
$sellerID = $_SESSION['sellerID'];
$sql_seller_products=  "SELECT * FROM products WHERE sellerID = '$sellerID'" ;
$sql_seller_product_result = mysqli_query($conn, $sql_seller_products); 
$total_seller_products = mysqli_num_rows($sql_seller_product_result); 

//--------- ORDERS -- to be fulfilled *DISTINCT (not repeating orderID -- counts orders )
$sql_seller_orders = "
    SELECT DISTINCT orders.orderID
    FROM orders
    JOIN order_products ON orders.orderID = order_products.orderID
    JOIN products ON order_products.productID = products.productID
    WHERE products.sellerID = '$sellerID'
    AND (orders.orderStatus = 'Placed' OR orders.orderStatus = 'Paid')
";
$sql_seller_order_result = mysqli_query($conn, $sql_seller_orders);
$total_seller_orders = mysqli_num_rows($sql_seller_order_result); //number of rows = count of orders
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Panel</title>

    <link rel="stylesheet" href="../styleV2.css">
    <link rel="stylesheet" href="seller_panel_style.css?v=<?php echo time(); ?>">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->

    <style>
        /* Container for Dashboard Cards */
        .sellerPanelDashboardCards {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap; /* added to wrap around */
        }

        /* Dashboard cards -- black, with white text top info */
        .sellerPanelProductsCard,
        .sellerPanelOrdersCard {
            width: 200px;
            background: black;
            color: white;
            margin: 10px;
            padding: 2px 10px;
        }
        .sellerPanelProductsCard p {
            color: blueviolet;
            padding: 10px;
            font-weight: bold;
        }
        .sellerPanelOrdersCard p {
            color: goldenrod; 
            padding: 10px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo">
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="sellerPanelContainer">
            <!-- Seller panel sidebar (left shows functionality within ul>li) -->
            <div class="sellerPanelSidebar">

            <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
                <li><a href="../welcome_landing.php">
                        <!-- Logo -->
                        <div class="logoSpazaShapPanel">
                            <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                            style="align-content:center;">
                        </div>
                    </a>
                </li>

                <h2>SpazaShap Seller</h2>
                <ul>
                    <li>
                        <a href="seller_panel.php">Seller Panel</a>
                    </li>
                    <li>
                        <a href="seller_add_product.php">Add Product</a>
                    </li>
                    <li>
                        <a href="seller_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="seller_view_orders.php">Orders</a>
                    </li>
                </ul>
            </div>


            <div class="sellerContentRight">
                <h2> Seller Panel </h2>
                <div class="sellerPanelDashboardCards">

                    <div class="sellerPanelProductsCard">
                        <!-- #NR PRODUCTS -->
                        <h3>Total Products:</h3>
                        <hr>
                        <p><?php echo $total_seller_products ?></p>
                    </div>

                    <div class="sellerPanelOrdersCard">
                        <!-- #NR ORDERS -- 0 at first -->
                        <h3>Total Orders:</h3>
                        <hr>
                        <p><?php echo $total_seller_orders?></p>
                    </div>
                </div>

            </div>
        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>