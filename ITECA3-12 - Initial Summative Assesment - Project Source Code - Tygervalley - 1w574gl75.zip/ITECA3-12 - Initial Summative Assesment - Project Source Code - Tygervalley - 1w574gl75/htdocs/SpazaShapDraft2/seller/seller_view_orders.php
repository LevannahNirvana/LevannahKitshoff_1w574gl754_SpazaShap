<?php
//Levannah kitshoff - June 2025
// seller_view_orders.php
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html");  //or ../welcome_landing.php")
    exit();
}
//if not a SELLER **CHECK ROLE   (should only allow admin access here)
if ($_SESSION["userRole"] != "Seller") {
    header("Location: ../welcome_landing.php"); //or admin/admin_panel if role is admin
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Admins"; //maybe give a message ???
}

//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once '../include/dbconnect.php'; 
?>

<?php
//---DELETE FUNCTIONALITY ADDED--- 
if (isset($_GET['orderID'])) {
    //if -->  delete button clicked -- gets +sets the orderID
    $orderID = $_GET['orderID'];
    $delete_order_sql = "DELETE FROM orders where orderID='$orderID' ";
    $order_data = mysqli_query($conn, $delete_order_sql);
    if ($order_data) {
        header("Location: admin_view_orders.php"); //if successful - send user to same place
    }
}
//-------------fin delete-----------------

//---UPDATE FUNCTIONALITY --- on seller_update_orders.php page

//VIEW ALL ORDERS -- for specific seller **where Placed or Paid  (not cart)
$sellerID = $_SESSION['sellerID']; //session for sellerID

/* $sql_seller_orders = "SELECT * FROM orders 
WHERE orderStatus = 'Placed' OR orderStatus = 'Paid'"; */
$sql_seller_orders = "
    SELECT 
        orders.orderID,
        orders.orderDate,
        orders.orderTotal,
        orders.orderStatus,
        products.productID,
        products.productName,
        order_products.quantity
    FROM orders
    JOIN order_products ON orders.orderID = order_products.orderID
    JOIN products ON order_products.productID = products.productID
    WHERE products.sellerID = '$sellerID'
    AND (orders.orderStatus = 'Placed' OR orders.orderStatus = 'Paid')
    ORDER BY orders.orderDate DESC";
$all_seller_orders_result  = mysqli_query($conn, $sql_seller_orders);

//error handling -- if unsuccessful query for seller orders
if (!$all_seller_orders_result ) {
    die("Seller Orders Query Error: ".mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin: All Orders</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css">
    <link rel="stylesheet" href="seller_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->

    <style>
        /* =======================SELLER VIEW ORDERS PAGE================*/
        /* all above layout repeats throughout the panel pages */

        /* table class="seller_table_orders" */
        .seller_table_orders {
            border: 3px solid black;
            margin-top: 35px;
        }
        th {
            background: #2f84d9;
            font-weight: bold;
            text-align: center;
            padding: 9px;
        }
        td {
            text-align: center;
            padding: 10px 5px;
            margin: 5px 5px;
        }

        /* ===================SELLER UPDATE/DELETE ORDERS PAGE==============*/
        /* =======DELETE ORDERS ======== */
        .panel_delete_btn {
            border-radius: 15px;
            background: red;
            padding: 8px;
        }
        .panel_delete_btn:hover {background-color: darkred;}

        /* =======UPDATE ORDERS ======== */
        .panel_update_btn {
            border-radius: 15px;
            background: orange;
            padding: 8px;
        }
        .panel_update_btn:hover {background-color: darkorange;}
    </style>
</head>

<body>
    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo">
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="sellerPanelContainer">
            <!-- Seller panel sidebar (left shows functionality within ul>li) -->
            <div class="sellerPanelSidebar">

            <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
                <li><a href="../welcome_landing.php">
                        <!-- Logo -->
                        <div class="logoSpazaShapPanel">
                        <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                        style="align-content:center;"> 
                        </div>
                    </a>
                </li>

                <h2>SpazaShap Seller</h2>
                <ul>
                    <li>
                        <a href="seller_panel.php">Seller Panel</a>
                    </li>
                    <li>
                        <a href="seller_add_product.php">Add Product</a>
                    </li>
                    <li>
                        <a href="seller_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="seller_view_orders.php">Orders</a>
                    </li>
                </ul>
            </div>

            <div class="sellerContentRight">
                <h1> Seller Panel: Seller Orders</h1>
                <table class="seller_table_orders">
                        <!-- Table Row -- for headers -->
                        <tr>
                            <!--from orders table-->
                            <th>OrderID</th>
                            <th>Order Date</th>
                            <th>Order Total</th>
                            <th>Order Status </th>

                            <!--from order_products table--> 
                            <th>Order Product Name </th>
                            <th>Product Quantity</th>
                            
                            <!-- <th>Delete</th> --> 
                            <!-- <th>Update</th> --> 
                        </tr>
            <?php
            //if there is result and rows for order (seller orders) & while there is rows/orders...
            if ($all_seller_orders_result && mysqli_num_rows($all_seller_orders_result) > 0) {
                while ($seller_orderRow = mysqli_fetch_assoc($all_seller_orders_result)) {
            ?>
                    <!-- Table row for Data (4 headers thus 4 data) -->
                <tr>
                    <!--orderID-->
                    <td><?php echo $seller_orderRow['orderID'] ?></td>
                    <!--orderDate-->
                    <td><?php echo $seller_orderRow['orderDate'] ?></td>
                    <!--orderTotal-->
                    <td><?php echo $seller_orderRow['orderTotal'] ?></td>
                    <!--orderStatus-->
                    <td><?php echo $seller_orderRow['orderStatus'] ?></td>

                    <!--  ------ from order_products table -----  --> 
                    <!--Order Product (productID or productName)???-->
                    <!-- <td><?php echo $seller_orderRow['productID'] ?></td> -->
                    <td><?php echo $seller_orderRow['productName']; ?></td>
                    <!--Product Quantity (quantity)-->
                    <td><?php echo $seller_orderRow['quantity'] ?></td>

                    <!-- Removed DELETE -->
                    <!-- --> 
                    <!-- Removed Update -->
                    <!-- -->
                </tr>
            <?php }
            } else {
                echo "<p>No Orders found.</p>";
            }
            ?>
        </table>
        <br><br>  
        </div>

    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>