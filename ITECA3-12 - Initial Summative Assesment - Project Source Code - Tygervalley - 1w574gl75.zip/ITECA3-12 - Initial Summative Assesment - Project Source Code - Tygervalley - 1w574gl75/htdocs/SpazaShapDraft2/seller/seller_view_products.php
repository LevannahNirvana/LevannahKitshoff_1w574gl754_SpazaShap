<!-- Levannah Kitshoff - 24 May -- seller_view_products -->
<?php
//--------------- SESSIONS --------------
session_start();
//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html");  //or ../welcome_landing.php")
    exit();
}
//if not a SELLER **CHECK ROLE   (should only allow seller access here)
if ($_SESSION["userRole"] != "Seller") {
    header("Location: ../welcome_landing.php"); //or seller/seller_panel if role is seller
    exit(); //stop script after redirection
    echo "Restricted Functionality - Only Allowed For Sellers"; //msg
}

//---------DB CONNECTION---------------
/* can reuse for db connection with error check --use conn for queries */
require_once '../include/dbconnect.php'; 

//---DELETE FUNCTIONALITY--
if (isset($_GET['productID'])) {
    //if -->  delete button clicked -- gets +sets the productID
    $productID = $_GET['productID'];
    $delete_product_sql = "DELETE FROM products where productID='$productID' ";
    $product_data = mysqli_query($conn, $delete_product_sql);
    if ($product_data) {
        header("Location: seller_view_products.php"); //if successful - send user to same place
    }
}
//---------------fin delete------------------ :)


//---UPDATE FUNCTIONALITY --- on seller_update_product.php page
//no search 

// VIEW ALL PRODUCTS for specific Seller    
$sellerID = $_SESSION["sellerID"]; //get sellerID for the products for specific seller
//SQL all seller specific products with category via a join  **including category 
$sql_seller_products = "SELECT products.*, product_categories.categoryName FROM products
LEFT JOIN product_categories ON products.categoryID = product_categories.categoryID
WHERE sellerID ='$sellerID'";

/* $sql_seller_products = "SELECT * FROM products WHERE sellerID ='$sellerID'"; */
$seller_products_result = mysqli_query($conn, $sql_seller_products);

//error handling -- if unsuccessful query for all products
if (!$seller_products_result) {
    die("Seller Products Query Error: ".mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller: Products</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css">
    <link rel="stylesheet" href="seller_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->

    <style>
        /* =======================SELLER VIEW PRODUCTS PAGE================*/
        /* all above layout repeats throughout the panel pages */

        /* table class="seller_table_products" */
        .seller_table_products {
            border: 3px solid black;
            margin-top: 35px;
        }
        /* NOT WORKING: (tr table row) TABLE HEADER ROW (th)
        .seller_table_products>tr>th {} 
        .seller_table_products>tr>th { */
        th {
            background: #2f84d9;
            font-weight: bold;
            text-align: center;
            padding: 9px;
        }
        td {
            text-align: center;
            padding: 5px;
        }

        /* ===================SELLER UPDATE/DELETE PRODUCTS PAGE==============*/
        /* =======DELETE PRODUCTS ======== */
        .panel_delete_btn {
            border-radius: 15px;
            background: red;
            padding: 8px;
        }
        .panel_delete_btn:hover {background-color: darkred;}

        /* =======UPDATE PRODUCTS ======== */
        .panel_update_btn {
            border-radius: 15px;
            background: orange;
            padding: 8px;
        }
        .panel_update_btn:hover { background-color: darkorange; } 
    </style>
</head>

<body>
    <header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo">
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="mainPanel">
        <div class="sellerPanelContainer">
            <!-- Seller panel sidebar (left shows functionality within ul>li) -->
            <div class="sellerPanelSidebar">

                <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
                <li><a href="../welcome_landing.php">
                        <!-- Logo -->
                        <div class="logoSpazaShapPanel">
                            <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                            style="align-content:center;">
                        </div>
                    </a>
                </li>

                <h2>SpazaShap Seller</h2>
                <ul>
                    <li>
                        <a href="seller_panel.php">Seller Panel</a>
                    </li>
                    <li>
                        <a href="seller_add_product.php">Add Product</a>
                    </li>
                    <li>
                        <a href="seller_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="seller_view_orders.php">Orders</a>
                    </li>
                </ul>
            </div>

            <div class="sellerContentRight">
                <h1> Seller Panel: All Products</h1>
                <!-- no search  -->
                    <table class="seller_table_products">
                        <!-- Table Row -- for headers -->
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Stock Quantity</th>
                            <th>Category</th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>

                        <?php
                        $result = $seller_products_result;

                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($productRow = mysqli_fetch_assoc($result)) {
                        ?>
                        <!-- Table row for Data (5 headers thus 5 data) -->
                        <tr>
                            <td>
                                <!-- width 100 px & height style needed here! -->
                                <img class="seller_productImage" alt="product image" 
                                width='100px' height='100px' 
                                src="../product_images/<?php echo htmlspecialchars($productRow['productImageSource']) ?>">
                            </td>
                            <td><?php echo $productRow['productName'] ?></td>
                            <td><?php echo $productRow['productDescription'] ?></td>
                            <td><?php echo $productRow['productPrice'] ?></td>
                            <td><?php echo $productRow['productStockQuantity'] ?></td>
                            <!-- product_categories joined to products -->
                            <td><?php echo htmlspecialchars($productRow['categoryName']) ?></td>

                            <!-- DELETE -->
                            <td>
                                <a onclick="return confirm('Are you sure you want to delete product?');" 
                                class="panel_delete_btn" 
                                href="seller_view_products.php?productID=<?php echo $productRow['productID'] ?>">DELETE</a>
                                <!-- id will come from db -->
                            </td>

                            <!-- UPDATE -->
                            <td>
                                <a class="panel_update_btn" 
                                href="seller_update_product.php?productID=<?php echo $productRow['productID'] ?>">UPDATE</a>
                            </td>
                        </tr>
                                
                        <?php }
                        } else {
                            echo "<p>No products found.</p>";
                        }
                        ?>
                    </table>
                <br><br>
            </div>

        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>