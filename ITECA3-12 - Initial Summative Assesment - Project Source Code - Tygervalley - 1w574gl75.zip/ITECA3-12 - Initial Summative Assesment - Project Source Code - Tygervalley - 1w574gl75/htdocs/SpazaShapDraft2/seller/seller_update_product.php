<?php
/* Levannah Kitshoff - 25 May 2025 - seller_update_product.php  */
//--------------- SESSIONS --------------
session_start();

//----CHECK userLoggedIn  & CHECK  SELLER  ------------
//check if session is set (for userLoggedIn) & checking is $_SESSION is true
if (!isset($_SESSION["userLoggedIn"]) || $_SESSION["userLoggedIn"] !== true) {
    header("Location: ../login.html"); //or login.html
    exit();
}
//if not a SELLER **CHECK ROLE   (should only allow seller access here)
if ($_SESSION["userRole"] != "Seller") {
    header("Location: ../welcome_landing.php"); //or seller/seller_panel 
    exit(); //stop script after redirection
    //maybe give a message ???
    echo "Restricted Functionality - Only Allowed For Sellers";
}
?>

<?php
//---------DB CONNECTION---------------
/*reuse db connection w/ error check --use conn for queries */
require_once '../include/dbconnect.php';

//UPON LOAD  -- show categories in select option 
//Setup for categoryQuery 
$categoryQuery = mysqli_query($conn, "SELECT categoryID, categoryName FROM product_categories");
//---------------------------------------

//------- SQL for displaying current existing product data ---------
//PRODUCT ID  (FROM PREV PAGE OVER TO THIS PAGE) & Fetch product from DB
if (!isset($_GET['productID'])) {
    die("Error: Product ID not provided.");
}
$productID = $_GET['productID'];
$sql_select_product = "SELECT * FROM products WHERE productID = '$productID'";
$select_product_result = mysqli_query($conn, $sql_select_product);
$productRow = mysqli_fetch_assoc(($select_product_result));
//------------------------------------------------------------------

//===============IF SUBMIT UPDATE PRODUCT BUTTON CLICKED=============
if (isset($_POST['updateProductSubmitBtn'])) {
    /* if ($_SERVER["REQUEST_METHOD"] == "POST") { */

    //============GET UPDATE FORM DATA===================
    //categoryID ---via categoryName on select option  //sellerID  -- via db product table sellerID  **keep the same
    $productName = trim($_POST['productName']);
    $productDescription = trim($_POST['productDescription']);
    $productPrice = trim($_POST['productPrice']);
    /* $productImageSource */ // image handling occurs at a later stage
    $productStockQuantity = trim($_POST['productStockQuantity']);
    /* $productStatus = "Available";  */ //decide if want to add available //same unless 0   
    $categoryID = $_POST['productCategories']; // gets categoryID from db loaded select option value
    //$sellerID = (int)$_SESSION["sellerID"]; //sellerID from the stored SESSION Variable  **STRING TO INT
    //sanitize more.... 

    //======= CHECK IF FIELDS ARE EMPTY ==========
    //!! allow for productDescription, productImageSource -- to be null
    if (empty($productName) || empty($productPrice) || empty($productStockQuantity) || empty($categoryID))      {
        //|| empty($sellerID)
        echo "Error: Fill in All Required Fields";
        exit;
    }

    //----------CHECK IF IMAGE EMPTY
    //SETUP FOR IMAGE FILE SOURCE (for productImageSource -- input field)
    $productImageFileName = $_FILES['productImageSource']['name'];

    //check file empty or not... in input field
    if ($productImageFileName) {
        $temp = explode(".", $productImageFileName); //split image name file ext

        $timestamp = round(microtime(true)); //gets rounded timestamp - unique name
        $fileExtension = end($temp); //gets file extension
        $newProductImageFileName = $timestamp . '.' . $fileExtension;
        //-----
        /*^^FIXED Error: -->  $newProductImageFileName =  round(microtime(true). '.' . end($temp));  */
        /* Past:  $productImageTempFileName = $_FILES['productImageSource']['tmp_name']; */
        $upload_folder = '../product_images/' . $newProductImageFileName;

        //MOVE UPLOADED FILE -- from, to 
        move_uploaded_file($_FILES['productImageSource']['tmp_name'], $upload_folder);

        //-----------------------------
        //============= SQL UPDATE  (WITH IMAGE)====================
        $sql_update_product = "UPDATE products 
        SET productName = '$productName', 
        productDescription = '$productDescription', 
        productPrice= '$productPrice', 
        productImageSource = '$newProductImageFileName',  /* newProductImageFileName */
        productStockQuantity = '$productStockQuantity', 
        /* productStatus = ?, */ 
        /* sellerID = ?, */ 
        categoryID = '$categoryID'
        WHERE productID = '$productID'";

        $update_data = mysqli_query($conn, $sql_update_product);

        //redirect back to seller_view_products  (after product update)
        if ($update_data) {
            header("Location: seller_view_products.php");
        }
    } else {
        //============= SQL UPDATE  (no image)====================
        $sql_update_product = "UPDATE products 
        SET productName = '$productName', 
        productDescription = '$productDescription', 
        productPrice= '$productPrice', 
        /* productImageSource = '$productImageSource',  */
        productStockQuantity = '$productStockQuantity', 
        /* productStatus = ?, */ 
        /* sellerID = ?, */ 
        categoryID = '$categoryID'
        WHERE productID = '$productID'";

        $update_data = mysqli_query($conn, $sql_update_product);

        //redirect back to seller_view_products  (after product update)
        if ($update_data) {
            header("Location: seller_view_products.php");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Update Product</title>

    <link rel="stylesheet" href="/SpazaShapDraft2/styleV2.css">
    <link rel="stylesheet" href="seller_panel_style.css">
    <!-- BOTH STYLESHEETS NEEDED (combo) -->
    <style>
        .sellerContentRight {
            border: solid 1pt black;
            width: 80%; /*  added to fill more of content */
            margin-top: 10px;
            padding: 10px;
        }

        /* ---------------------------------------------------------- */
        .sellerFormUpdateProduct {justify-content: center; }

        .form_area_div {padding: 8px;}
        .form_area_div>label {
            width: 150px;
            display: inline-block;
        }
        .form_area_div>input[type='text'],
        [type='number'] {
            padding: 10px;
            width: 30%;/* same weidth as others (inputs) */
            resize: vertical;/* only adjust height of element */
            box-sizing: border-box;
        }
        .form_area_div>textarea {
            height: 80px;/* larger starting height */
            width: 30%;/* same weidth as others (inputs) */
        }

        /* ================================ */
        /* --- Current Image of Specific Selected Product --- */
        .currentImage {
            border: 1pt solid black;
            box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.1);
            padding: 2pt;
        }
        .currentImage>img {
            width: 150px;
            height: 150px;
        }

        /* ---UPDATE PRODUCT BUTTON--- */
        .form_area_div>#updateProductSubmitBtn {
            background-color: blue;
            width: 150px;
        }
        .form_area_div>#updateProductSubmitBtn:hover {background-color: dodgerblue;}

        /* ---CANCEL UPDATE PRODUCT BUTTON--- */
        .form_area_div>a>#updateProductCancelBtn {
            background-color: red;
            width: 150px;
        }
        .form_area_div>a>#updateProductCancelBtn:hover {background-color: darkred;}
        /* ================================ */
    </style>
</head>

<body>
<header>
        <!-- basic nav compared to other nav -->
        <nav class="navigationBarPanel">
            <!-- Logo -->
            <div class="logoSpazaShap">
                <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo"> 
                <p>Spaza Shap: Shopping Spaza Style</p>
            </div>

            <div class="logoutOnPanelNav">
                <ul class="navigationBarList logoutNavPanelLink"> <!-- navigationbarlist style applied -->
                    <li><a href="../logout.php" class="navPanelLogoutButton">Logout</a></li>
                </ul>
            </div>
        </nav>
</header>

    <main class="mainPanel">
        <div class="sellerPanelContainer">
            <!-- Seller panel sidebar (left shows functionality within ul>li) -->
            <div class="sellerPanelSidebar">

                <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
                <li><a href="../welcome_landing.php">
                        <!-- Logo -->
                        <div class="logoSpazaShapPanel">
                            <img src="../images/logoSpazaShap.png" alt="Spaza Shap Logo" 
                            style="align-content:center;">
                        </div>
                    </a>
                </li>

                <h2>SpazaShap Seller</h2>
                <ul>
                    <li>
                        <a href="seller_panel.php">Seller Panel</a>
                    </li>
                    <li>
                        <a href="seller_add_product.php">Add Product</a>
                    </li>
                    <li>
                        <a href="seller_view_products.php">Products</a>
                    </li>
                    <li>
                        <a href="seller_view_orders.php">Orders</a>
                    </li>
                </ul>
            </div>

            <div class="sellerContentRight">
                <h2> Seller Update Product</h2>

                <form class="sellerFormUpdateProduct"
                    action="" method="POST"
                    enctype="multipart/form-data">
                    <!-- action="seller_update_product.php" -->

                    <!--productName-->
                    <div class="form_area_div">
                        <label for="productName">Product Name:</label>
                        <input type="text" name="productName" id="productName" 
                        placeholder="e.g. Jean Jacket" value="<?php echo $productRow['productName'] ?>">
                        <!-- <span id="productNameError" class="error"></span> -->
                    </div>

                    <!--productDescription-->
                    <div class="form_area_div">
                        <label for="productDescription">Product Description:</label>
                        <textarea name="productDescription" id="productDescription"
                            placeholder="e.g. Jean Jacket perfect for outdoors. Made From Denim..."
                            maxlength=400><?php echo $productRow['productDescription'] ?>
                        </textarea>
                        <!-- <span id="productDescriptionError" class="error"></span> -->
                    </div>

                    <!-- productPrice -->
                    <div class="form_area_div">
                        <label for="productPrice">Product Price: (R)</label>
                        <input type="number" step="0.01" min="0" oninput="this.value = Math.abs(this.value)" 
                            name="productPrice" id="productPrice" placeholder="9.99"
                            value="<?php echo $productRow['productPrice'] ?>">
                        <!-- <span id="productPriceError" class="error"></span>  -->
                    </div>


                    <!-- DISPLAY IMAGE & Give option to choose file for a different image -->
                    <div class="currentImage">
                        <label for="">Current Product Image:</label>
                        <img src="../product_images/<?php echo $productRow['productImageSource'] ?>"> <!-- width="150" height="150" -->
                    </div>

                    <!-- productImageSource  -->
                    <div class="form_area_div">
                        <label for="productImageSource">Product Image Source:</label>
                        <input type="file" name="productImageSource" id="productImageSource"
                            accept="image/png, image/gif, image/jpeg"> <!--or accept="image/*"-->
                        <!-- <span id="productImageSourceError" class="error"></span> -->
                    </div>

                    <!-- productStockQuantity-->
                    <div class="form_area_div">
                        <label for="productStockQuantity">Product Stock Quantity:</label>
                        <input type="number" min="0" 
                        oninput="this.value = Math.abs(this.value)" name="productStockQuantity"
                            id="productStockQuantity" placeholder="20"
                            value="<?php echo $productRow['productStockQuantity'] ?>">
                        <!-- <span id="productStockQuantityError" class="error"></span> -->
                    </div>
                    <!--  -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->

                    <!--  !!! categoryID -- give predefined categories -->
                    <div class="form_area_div">
                        <!-- input for the different Product categories 
                        -- can be pre-added in DB then sourced to populate here -->
                        <label for="productCategories"> Product Categories:</label>
                        <select name="productCategories" id="productCategories">
                            <!-- <option value="">--Choose a Product Category--</option> -->
                            <!-- php to add category id and category name 
                            in select option html elements -->
                            <?php while ($categoryRow = mysqli_fetch_assoc($categoryQuery)):  
                            /*while more categories*/ ?>

                                <option
                                    value="<?php echo $categoryRow['categoryID']; ?>">
                                    <!-- if product categoryID is the category loaded.. -->
                                    <!-- >>> selected productcategory -->
                                    <?php if ($productRow['categoryID'] == $categoryRow['categoryID'])
                                        echo '>>>'; ?>
                                    <?php echo htmlspecialchars($categoryRow['categoryName']); ?>
                                </option>

                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!--  -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
                    <!--buttons submit & cancel-->
                    <div class="form_area_div">
                        <button id="updateProductSubmitBtn" type="submit" 
                        name="updateProductSubmitBtn" value="Update product">
                        <b>Update Product</b></button>
                        <a href="seller_view_products.php">
                            <button id="updateProductCancelBtn" type="button" 
                            name="updateProductCancelBtn">
                                <b>Cancel</b>
                            </button>
                        </a>
                    </div>
                </form>

            </div>
        </div>
    </main>
    <!-- FOOTER php-->
    <?php include '../include/footer.php'; ?>
</body>
</html>
