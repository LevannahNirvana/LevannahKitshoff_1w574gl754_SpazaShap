<!-- Levannah Kitshoff - April 2025 -->
<!-- nonUSer_index.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spaza Shap</title>

    <!--CSS Style-->
    <link rel="stylesheet" href="styleV2.css">

    <style>
        /*=================== NON USER ROLE - REG/LOGIN **CONTINUE  ====================== */
        .registerChoiceContainer {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-evenly;
            align-items: center;

            gap: 5.5rem;
            padding: 2rem 2rem;
            min-height: 60vh;
            min-width: 4.5rem;
            align-items: stretch;

            margin: 1rem 1rem -5rem 1rem;
            background: #ffffffb5;
        }

        /*good*/
        .admin {
            background-color: #fd5757;
            border: solid 2pt #fd5757d6;
        }

        /*good*/
        .seller {
            background-color: #2f84d9;
            border: solid 2pt #2f84d9c2;
        }

        /*good*/
        .buyer {
            background-color: #459349;
            border: solid 2pt #459349fc;
        }

        /* ----DIFFERENT USERROLE BLOCKS - For register ---- */
        .link_userRole {
            border-radius: 10px;
            width: 22rem;
            height: 30vh;
            padding: 1rem;

            /* FLEX & put text/links in center */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;

            /*link*/
            text-decoration: none;
            color: white;

            /*transform*/
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .link_userRole:hover {
            transform: scale(1.2); /*when hover -- enlarge userRole*/
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5); /*when hover -- add some shadow userRole*/
        }

        .link_userRole>span {
            font-size: 2rem;
            margin-bottom: 1rem;
        }

        .nonUserParagraph {
            background: #ffffff90; /* offwhite grey */
            margin-top: 20px;
        }

        .nonUserParagraph>p {
            font-weight: bold;
            font-family: Arial, Helvetica, sans-serif;
        }
    </style>
</head>

<body>
    <header>
        <nav class="navigationBar">
        <!-- Clickable Logo to redirect to Home / Welcome Landing Page -->
            <a id="aLogoClickableLogin" href="welcome_landing.php">
                <!-- Logo -->
                <div class="logoSpazaShap">
                        <img src="images/logoSpazaShap.png" alt="Spaza Shap Logo">
                        <p>Spaza Shap: Shopping Spaza Style</p>
                </div>
            </a>
        </nav>
    </header>

    <main>
        <div class="nonUserParagraph">
            <h2>Choose User Role you want to Register/Login as:</h2>
            <p>Buyers - Buy Products </p>
            <p>Sellers - Sell Products</p>
            <p>Admins - Making sure all the buyers and sellers are sorted </p>
        </div>


        <div class="registerChoiceContainer">
            <a href="buyer_register.html" class="link_userRole buyer">
                <span>Register as Buyer</span>
            </a>
            <a href="seller_register.html" class="link_userRole seller">
                <span>Register as Seller</span>
            </a>
            <a href="admin_register.html" class="link_userRole admin">
                <span>Register as Admin</span>
            </a>
        </div>
    </main>

    <!-- FOOTER php-->
    <?php include 'include/footer.php'; ?>

    <!-- JavaScript Script -->
    <script></script>
</body>
</html>
