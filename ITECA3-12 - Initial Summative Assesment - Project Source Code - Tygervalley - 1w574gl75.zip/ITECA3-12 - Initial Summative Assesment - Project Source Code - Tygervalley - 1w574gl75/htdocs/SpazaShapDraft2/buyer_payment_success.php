<?php
//Levannah Kitshoff - June 2025 
// buyer_payment_success.php
session_start(); //start session
require_once 'include/dbconnect.php'; //DB CONNECTION from within include folder

//Check that orderID and finalTotal -- received by POST (form)
if (!isset($_POST['orderID'], $_POST['finalTotal'])) {
    echo "Invalid access.";
    exit();
}
//get orderID, finalTotal (post)  & date *today
$orderID = intval($_POST['orderID']); //intval -- value to integer
$finalTotal = floatval($_POST['finalTotal']); // floatval -- value to float
$today = date("Y-m-d");

// Finalize the order -DELIVERY OPTION  
//-- set orderStatus to Paid, set OrderDate (today), OrderTotal
$sql = "UPDATE orders 
        SET orderStatus = 'Paid',
            orderDate = '$today',
            orderTotal = '$finalTotal'
        WHERE orderID = '$orderID'";

if (mysqli_query($conn, $sql)) {
    // UNSET SESSIONS vars
    unset($_SESSION["orderID"]);
    unset($_SESSION["finalTotal"]);
    unset($_SESSION["shippingCost"]);
    unset($_SESSION["baseTotal"]);
    unset($_SESSION["deliveryOption"]);

    //temp added for testing 
    //echo "Current directory: " . __DIR__;

    //Redirect to buyer_orders.php  -- with payment=success GET variable value
    header("Location: ./buyer_orders.php?payment=success"); //explicit relative path - due to error
    exit();
} else {
    echo "Delivery Order Completion failed: ".mysqli_error($conn);
}
?>
