<?php
//Levannah Kitshoff - April 2025 
//login.php 

session_start(); //start session
//---------------------------------------------------------------------
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //Email, Password  **userRole

    //============GET AND VALIDATE DATA===================
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $userRole = $_POST['userRoles'];

    //CHECK IF Email and Password fields are empty
    if (empty($email) || empty($password) || $userRole == "") {
        die("Error: All fields are required");
    } /*check userrole check*/

    //Validate email for all user role types
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Error: Invalid Email Format (SS Validation)");
        //die or echo --- die --stops execution (will not continue but sends err message to user)
    }

    //================DATABASE CONNECTION========================
    //------------- DATABASE CONNECT (INSERT PRODUCT)   *PROCEDURAL
    //#1 DB Connection Variables & #2 DB CONNECT & #3 CHECK DB CONNECT 
    require_once 'include/dbconnect.php';  
    //works - inside same directory is include file - within it is dbconnect

    //================ #4 CHECK CREDENTIALS  (BASED ON USER ROLE) =========================
    // Check UserRole
    if ($userRole == 'Buyer') {
        //------------BUYER------------
        $sql_check_buyer_email = "SELECT * FROM buyers WHERE buyerEmail ='$email'";
        $buyer_check = mysqli_query($conn, $sql_check_buyer_email);

        if (mysqli_num_rows($buyer_check) > 0) {
            $buyer = mysqli_fetch_assoc($buyer_check);

            //VERIFY PASSWORD
            /* if (password_verify($password, $buyer["password"])) {  <---- need to match db col name*/
            if (password_verify($password, $buyer["buyerPassword"])) {
                //Set session variables (when correct password)
                $_SESSION["userLoggedIn"] = true;
                $_SESSION["email"] = $email;
                $_SESSION["userRole"] = $userRole;

                //set the buyerID in session 
                $buyerID = $buyer["buyerID"];
                $_SESSION["buyerID"] = $buyerID;
                //WORKS

                //Redirect to Welcome Landing Page
                header("Location: welcome_landing.php");
                exit(); //stop script after redirection

            } else {
                echo "Error: Incorrect password";
            }
        } else {
            echo "Error: Email not found";
        }
        //-----------------------------------

    } else if ($userRole == 'Seller') {
        //------------SELLER------------
        $sql_check_seller_email = "SELECT * FROM sellers WHERE sellerEmail ='$email'";
        $seller_check = mysqli_query($conn, $sql_check_seller_email);

        if (mysqli_num_rows($seller_check) > 0) {
            $seller = mysqli_fetch_assoc($seller_check);

            //VERIFY PASSWORD
            if (password_verify($password, $seller["sellerPassword"])) {
                //Set session variables (when correct password)
                $_SESSION["userLoggedIn"] = true;
                $_SESSION["email"] = $email;
                $_SESSION["userRole"] = $userRole;

                //set the sellerID in session 
                $sellerID = $seller["sellerID"];
                $_SESSION["sellerID"] = $sellerID;

                //Redirect to Seller panel 
                header("Location: seller/seller_panel.php"); 
                exit(); //stop script after redirection

            } else {
                echo "Error: Incorrect password";
            }

        } else {
            echo "Error: Email not found";
        }
        //-----------------------------------

    } else if ($userRole == 'Admin') {
        //--------ADMIN--------------
        //CHECK IF EMAIL EXISTS (ADMIN)
        $sql_check_admin_email = "SELECT * FROM admins WHERE adminEmail ='$email'";
        $admin_check = mysqli_query($conn, $sql_check_admin_email);

        if (mysqli_num_rows($admin_check) > 0) {
            $admin = mysqli_fetch_assoc($admin_check);

            //VERIFY PASSWORD
            if (password_verify($password, $admin["adminPassword"])) {
                //Set session variables (when correct password)
                $_SESSION["userLoggedIn"] = true;
                $_SESSION["email"] = $email;
                $_SESSION["userRole"] = $userRole;

                //set the adminID in session 
                $adminID = $admin["adminID"];
                $_SESSION["adminID"] = $adminID;

                //Redirect to Welcome Landing Page
                header("Location: /SpazaShapDraft2/admin/admin_panel.php");
                exit(); //stop script after redirection

            } else {
                die("Error: Incorrect password");
            }

        } else {
            die("Error: EMAIL NOT FOUND");
        }
        //-----------------------------------
    }
    //CLOSE DB CONNECTION 
    mysqli_close($conn);
}